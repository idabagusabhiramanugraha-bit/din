// ============================================================================
// captions.ts : SATU-SATUNYA sumber waktu proyek.
// Semua timestamp cue di bawah disalin persis dari file SRT yang diberikan.
// Timing per kata dihitung proporsional jumlah huruf di dalam tiap cue.
// File ini sengaja tidak meng-import apa pun agar bisa dibaca juga oleh
// scripts/validate.mjs (Node).
// ============================================================================

export const FPS = 30;

/**
 * Pergeseran sinkronisasi (detik). Dipakai untuk subtitle DAN pergantian scene.
 *  - nilai positif  -> subtitle/visual muncul LEBIH LAMBAT dari audio
 *  - nilai negatif  -> subtitle/visual muncul LEBIH CEPAT dari audio
 * Audio selalu mulai di frame 0.
 */
export const AUDIO_OFFSET = 0;

/** Durasi tambahan setelah kata terakhir (detik). */
export const END_PAD_SEC = 1;

export type Cue = {n: number; start: number; end: number; text: string};

export const CUES: Cue[] = [
  {n: 1, start: 0.1, end: 5.3, text: 'Bagaimana jika besok pagi seluruh manusia di bumi tiba-tiba menjadi warga negara'},
  {n: 2, start: 5.3, end: 11.98, text: 'Indonesia? Bayangkan, 8 miliar orang mendadak punya KTP Indonesia. Pertama,'},
  {n: 3, start: 11.98, end: 17.12, text: 'Indonesia langsung menjadi negara dengan penduduk terbanyak di dunia. Bahkan negara'},
  {n: 4, start: 17.12, end: 21.62, text: 'lain mungkin mulai khawatir karena satu negara ini punya populasi lebih banyak'},
  {n: 5, start: 21.62, end: 27.58, text: 'daripada gabungan banyak benua. Tapi masalahnya, bayangkan 8 miliar orang harus'},
  {n: 6, start: 27.58, end: 33.14, text: 'mengantri untuk membuat KTP, SIM, dan mengurus administrasi. Belum lagi semuanya'},
  {n: 7, start: 33.14, end: 38.08, text: 'harus belajar satu hal penting. Kalau ditanya, "Bagaimana kabarnya?" Jawabannya'},
  {n: 8, start: 38.08, end: 43.56, text: 'harus, "Baik, alhamdulillah." Dunia kuliner juga bakal berubah drastis.'},
  {n: 9, start: 43.56, end: 48.86, text: 'Bayangkan, miliaran orang mulai mengenal nasi goreng, rendang, sambal, dan mi'},
  {n: 10, start: 48.86, end: 54.5, text: 'instan. Bahkan mungkin cabai menjadi komoditas paling berharga di dunia. Namun,'},
  {n: 11, start: 54.5, end: 60.32, text: 'ada satu masalah besar. Dengan 8 miliar orang Indonesia, kemungkinan besar kita'},
  {n: 12, start: 60.32, end: 65.82, text: 'harus memperluas grup WhatsApp keluarga sampai satu planet. Jadi, menurutmu,'},
  {n: 13, start: 65.82, end: 69.62, text: 'apakah dunia akan menjadi lebih baik jika semuanya menjadi orang Indonesia?'},
];

export const toFrame = (sec: number) => Math.round((sec + AUDIO_OFFSET) * FPS);

// ---------------------------------------------------------------- kata ----
export type Word = {text: string; norm: string; start: number; end: number; cue: number};

const norm = (t: string) => t.toLowerCase().replace(/[^a-z0-9]/g, '');
const letters = (t: string) => Math.max(1, (t.match(/[a-z0-9]/gi) || []).length);
// Ejaan mengikuti naskah narasi (SRT menulis "mengantri").
const fixSpelling = (t: string) => t.replace(/mengantri/i, 'mengantre');

function buildWords(): Word[] {
  const out: Word[] = [];
  for (const c of CUES) {
    const toks = c.text.split(/\s+/).filter(Boolean).map(fixSpelling);
    const total = toks.reduce((a, t) => a + letters(t), 0);
    let acc = 0;
    for (const t of toks) {
      const s = c.start + (acc / total) * (c.end - c.start);
      acc += letters(t);
      const e = c.start + (acc / total) * (c.end - c.start);
      out.push({text: t, norm: norm(t), start: s, end: e, cue: c.n});
    }
  }
  return out;
}

export const WORDS: Word[] = buildWords();
export const LAST_WORD_END = WORDS[WORDS.length - 1].end;

/** Durasi total = kata terakhir + 1 detik, dibulatkan ke frame. */
export const TOTAL_FRAMES = toFrame(LAST_WORD_END + END_PAD_SEC);

function findPhrase(phrase: string): number {
  const toks = phrase.split(' ');
  for (let i = 0; i + toks.length <= WORDS.length; i++) {
    if (toks.every((tk, k) => WORDS[i + k].norm === tk)) return i;
  }
  throw new Error('Frasa jangkar tidak ditemukan di SRT: ' + phrase);
}

// ------------------------------------------------------------- scene ------
export const SCENE_ORDER = [
  'S1', 'S2', 'S3', 'S4', 'S5', 'S6', 'S7', 'S8', 'S9', 'S10', 'S11',
  'S12', 'S13', 'S14', 'S15', 'S16', 'S17', 'S18', 'S19', 'S20', 'S21',
] as const;
export type SceneId = (typeof SCENE_ORDER)[number];

// Tiap scene dimulai tepat di kata jangkar berikut (waktu kata berasal dari SRT).
const ANCHORS: Record<Exclude<SceneId, 'S1'>, string> = {
  S2: 'indonesia',
  S3: 'mendadak',
  S4: 'indonesia langsung',
  S5: 'bahkan negara',
  S6: 'populasi lebih',
  S7: 'tapi masalahnya',
  S8: 'mengantre untuk',
  S9: 'belum lagi',
  S10: 'kalau ditanya',
  S11: 'jawabannya harus',
  S12: 'dunia kuliner',
  S13: 'bayangkan miliaran',
  S14: 'bahkan mungkin',
  S15: 'paling berharga',
  S16: 'ada satu',
  S17: 'dengan 8',
  S18: 'kemungkinan besar',
  S19: 'sampai satu',
  S20: 'jadi menurutmu',
  S21: 'apakah dunia',
};

export const SCENE_START_SEC: Record<SceneId, number> = (() => {
  const r = {S1: 0} as Record<SceneId, number>;
  (Object.keys(ANCHORS) as Array<Exclude<SceneId, 'S1'>>).forEach((id) => {
    r[id] = WORDS[findPhrase(ANCHORS[id])].start;
  });
  return r;
})();

export const SCENE_RANGE: Record<SceneId, {start: number; end: number}> = (() => {
  const r = {} as Record<SceneId, {start: number; end: number}>;
  SCENE_ORDER.forEach((id, i) => {
    const start = i === 0 ? 0 : toFrame(SCENE_START_SEC[id]);
    const next = SCENE_ORDER[i + 1];
    r[id] = {start, end: next ? toFrame(SCENE_START_SEC[next]) : TOTAL_FRAMES};
  });
  return r;
})();

export const BEATS: Array<{id: string; scenes: SceneId[]}> = [
  {id: 'B1', scenes: ['S1', 'S2', 'S3']},
  {id: 'B2', scenes: ['S4', 'S5', 'S6']},
  {id: 'B3', scenes: ['S7', 'S8', 'S9', 'S10', 'S11']},
  {id: 'B4', scenes: ['S12', 'S13', 'S14', 'S15']},
  {id: 'B5', scenes: ['S16', 'S17', 'S18', 'S19']},
  {id: 'B6', scenes: ['S20', 'S21']},
];

// ------------------------------------------------------------ subtitle ----
export type PageWord = {text: string; highlight: boolean; startFrame: number};
export type Page = {startFrame: number; endFrame: number; lines: PageWord[][]};

export const SUB_MAX_CHARS_PER_LINE = 23;
export const SUB_MAX_LINES = 2;

const HIGHLIGHT = new Set([
  '8', 'miliar', 'miliaran', 'ktp', 'sim', 'alhamdulillah', 'kuliner', 'cabai',
  'whatsapp', 'planet', 'terbanyak', 'benua', 'nasi', 'goreng', 'rendang', 'sambal',
]);

function buildPages(): Page[] {
  const pages: Page[] = [];
  let lines: PageWord[][] = [[]];
  let lens: number[] = [0];
  const flush = () => {
    if (lines[0].length === 0) return;
    pages.push({startFrame: lines[0][0].startFrame, endFrame: 0, lines});
    lines = [[]];
    lens = [0];
  };
  for (const w of WORDS) {
    const pw: PageWord = {text: w.text, highlight: HIGHLIGHT.has(w.norm), startFrame: toFrame(w.start)};
    let cur = lines.length - 1;
    const add = (lens[cur] === 0 ? 0 : 1) + w.text.length;
    if (lens[cur] + add > SUB_MAX_CHARS_PER_LINE) {
      if (lines.length === SUB_MAX_LINES) flush();
      else {
        lines.push([]);
        lens.push(0);
      }
      cur = lines.length - 1;
    }
    lens[cur] += (lens[cur] === 0 ? 0 : 1) + w.text.length;
    lines[cur].push(pw);
    if (/[.?!]$/.test(w.text) && lens.reduce((a, b) => a + b, 0) >= 20) flush();
  }
  flush();
  pages.forEach((p, i) => {
    p.endFrame = i < pages.length - 1 ? pages[i + 1].startFrame : TOTAL_FRAMES;
  });
  pages[0].startFrame = 0; // tidak ada frame tanpa subtitle di awal
  return pages;
}

export const PAGES: Page[] = buildPages();
