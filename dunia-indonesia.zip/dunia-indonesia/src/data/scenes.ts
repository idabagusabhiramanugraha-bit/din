import type {SceneId} from './captions';
import {SCENE_RANGE} from './captions';

export type Enter = 'none' | 'cut' | 'stamp' | 'wipe' | 'iris' | 'swipeUp' | 'whip';

/** Jenis transisi MASUK tiap scene (disesuaikan dengan isi cerita). */
export const SCENE_ENTER: Record<SceneId, Enter> = {
  S1: 'none',
  S2: 'wipe', // bendera menyapu -> manusia berjatuhan
  S3: 'whip', // pan cepat ke kerumunan
  S4: 'iris', // kerumunan "tersedot" ke KTP
  S5: 'whip',
  S6: 'wipe',
  S7: 'stamp', // masalah muncul mendadak
  S8: 'cut',
  S9: 'swipeUp', // lemas, jatuh ke bawah
  S10: 'cut',
  S11: 'stamp', // punchline
  S12: 'swipeUp',
  S13: 'wipe',
  S14: 'cut',
  S15: 'iris',
  S16: 'cut',
  S17: 'iris', // masuk ke layar HP
  S18: 'cut',
  S19: 'stamp',
  S20: 'wipe',
  S21: 'whip',
};

export const LEAD_FRAMES = 10;

/** Scene dengan transisi geser/iris/wipe mulai LEAD_FRAMES lebih awal agar scene sebelumnya masih terlihat di bawahnya. */
export const leadOf = (id: SceneId): number => {
  const e = SCENE_ENTER[id];
  return e === 'wipe' || e === 'iris' || e === 'swipeUp' || e === 'whip' ? LEAD_FRAMES : 0;
};

export const sceneFrames = (id: SceneId) => SCENE_RANGE[id].end - SCENE_RANGE[id].start;
