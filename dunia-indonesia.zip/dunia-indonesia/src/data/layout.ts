// ============================================================================
// layout.ts : semua koordinat eksplisit (piksel, kanvas 1080x1920).
// Tidak ada header (dihapus atas permintaan). Area animasi mulai dari y=0.
// File ini tanpa import agar bisa dibaca scripts/validate.mjs.
// ============================================================================

export const W = 1080;
export const H = 1920;

export type Box = {x: number; y: number; w: number; h: number};
/** bg = latar penuh (boleh ditimpa); ok = tumpang tindih disengaja (benda dipegang karakter). */
export type LBox = Box & {bg?: boolean; ok?: boolean};

export const ANIM_AREA: Box = {x: 0, y: 0, w: 1080, h: 1500};
export const SAFE_MARGIN = 60;
export const LABEL_BOX: Box = {x: 60, y: 150, w: 960, h: 90};
export const CHAR_SAFE: Box = {x: 60, y: 300, w: 960, h: 1140};
export const SUBTITLE_BOX: Box = {x: 90, y: 1520, w: 900, h: 230};

export type SceneLayout = {char?: Box; objs: Record<string, LBox>; label?: boolean};

export const SCENE_LAYOUT: Record<string, SceneLayout> = {
  S1: {objs: {earth: {x: 190, y: 420, w: 700, h: 700}}, label: true},
  S2: {char: {x: 80, y: 700, w: 460, h: 700}, objs: {earth: {x: 560, y: 420, w: 440, h: 440}}},
  S3: {char: {x: 640, y: 980, w: 380, h: 460}, objs: {crowd: {x: 0, y: 380, w: 1080, h: 1000, bg: true}}, label: true},
  S4: {char: {x: 240, y: 480, w: 600, h: 900}, objs: {ktp: {x: 560, y: 760, w: 340, h: 220, ok: true}}, label: true},
  S5: {char: {x: 720, y: 1020, w: 300, h: 420}, objs: {map: {x: 0, y: 380, w: 1080, h: 760, bg: true}}, label: true},
  S6: {char: {x: 60, y: 840, w: 420, h: 600}, objs: {scale: {x: 490, y: 420, w: 550, h: 700}}},
  S7: {objs: {building: {x: 0, y: 380, w: 1080, h: 520, bg: true}, queue: {x: 0, y: 900, w: 1080, h: 600, bg: true}}, label: true},
  S8: {char: {x: 330, y: 820, w: 420, h: 620}, objs: {clock: {x: 700, y: 420, w: 260, h: 260}, queue: {x: 0, y: 380, w: 1080, h: 1060, bg: true}}, label: true},
  S9: {char: {x: 200, y: 900, w: 560, h: 540}, objs: {ticket: {x: 700, y: 820, w: 220, h: 300, ok: true}}},
  S10: {char: {x: 360, y: 600, w: 400, h: 840}, objs: {asker: {x: 60, y: 820, w: 240, h: 600}}},
  S11: {char: {x: 140, y: 440, w: 800, h: 900}, objs: {}},
  S12: {objs: {table: {x: 0, y: 700, w: 1080, h: 700, bg: true}, bunting: {x: 0, y: 380, w: 1080, h: 200, bg: true}}, label: true},
  S13: {char: {x: 100, y: 560, w: 560, h: 880}, objs: {plate: {x: 680, y: 1040, w: 340, h: 400}}},
  S14: {char: {x: 300, y: 520, w: 480, h: 900}, objs: {chili: {x: 500, y: 620, w: 300, h: 560, ok: true}}},
  S15: {objs: {earth: {x: 190, y: 560, w: 700, h: 700}}, label: true},
  S16: {char: {x: 220, y: 640, w: 520, h: 800}, objs: {phone: {x: 580, y: 820, w: 260, h: 420, ok: true}}},
  S17: {objs: {phone: {x: 140, y: 400, w: 800, h: 1040}}},
  S18: {objs: {phone: {x: 140, y: 400, w: 800, h: 1040}}, label: true},
  S19: {char: {x: 330, y: 820, w: 420, h: 620}, objs: {bubbles: {x: 0, y: 380, w: 1080, h: 1060, bg: true}}},
  S20: {char: {x: 120, y: 640, w: 480, h: 800}, objs: {earth: {x: 620, y: 380, w: 420, h: 420}}},
  S21: {char: {x: 240, y: 560, w: 600, h: 880}, objs: {title: {x: 90, y: 380, w: 900, h: 150}}},
};
