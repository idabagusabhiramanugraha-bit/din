import type {Box} from '../data/layout';
import {LABEL_BOX} from '../data/layout';
import {pop} from '../lib/anim';

/** Label informasi (nama tempat, angka). Muncul dengan efek "stempel" (skala + miring), bukan fade. */
export function Label({text, t, fps, delay = 0, box = LABEL_BOX, color = '#FFD400'}: {
  text: string; t: number; fps: number; delay?: number; box?: Box; color?: string;
}) {
  const s = pop(t, fps, delay, 9, 200);
  if (t < delay) return null;
  return (
    <div
      style={{
        position: 'absolute',
        left: box.x,
        top: box.y,
        width: box.w,
        height: box.h,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <div
        style={{
          transform: `scale(${0.4 + 0.6 * s}) rotate(${(1 - s) * -8 - 1.5}deg)`,
          background: '#111',
          color,
          border: '5px solid #fff',
          borderRadius: 14,
          padding: '8px 28px',
          fontFamily: '"Arial Black", Impact, Arial, sans-serif',
          fontWeight: 900,
          fontSize: 54,
          letterSpacing: 2,
          whiteSpace: 'nowrap',
          boxShadow: '6px 6px 0 rgba(0,0,0,0.35)',
        }}
      >
        {text}
      </div>
    </div>
  );
}
