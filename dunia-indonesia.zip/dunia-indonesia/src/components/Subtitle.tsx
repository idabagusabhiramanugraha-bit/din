import {useCurrentFrame, useVideoConfig} from 'remotion';
import {PAGES} from '../data/captions';
import {SUBTITLE_BOX} from '../data/layout';
import {pop} from '../lib/anim';

const FONT_SIZE = 56;
const LINE_H = 80;

/** Subtitle 2 baris maks., kotak kuning menyorot kata penting. Timing dari captions.ts (SRT). */
export function Subtitle() {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const page = PAGES.find((p) => frame >= p.startFrame && frame < p.endFrame) ?? PAGES[PAGES.length - 1];
  return (
    <div
      style={{
        position: 'absolute',
        left: SUBTITLE_BOX.x,
        top: SUBTITLE_BOX.y,
        width: SUBTITLE_BOX.w,
        height: SUBTITLE_BOX.h,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'flex-start',
        paddingTop: 22,
        boxSizing: 'border-box',
      }}
    >
      {page.lines.map((line, li) => (
        <div key={li} style={{height: LINE_H, display: 'flex', alignItems: 'center', whiteSpace: 'nowrap'}}>
          {line.map((w, wi) => {
            const s = w.highlight ? pop(frame - w.startFrame, fps, 0, 10, 220) : 1;
            const active = w.highlight && frame >= w.startFrame;
            return (
              <span
                key={wi}
                style={{
                  display: 'inline-block',
                  marginRight: wi === line.length - 1 ? 0 : 16,
                  padding: w.highlight ? '0 12px' : 0,
                  background: active ? '#FFD400' : 'transparent',
                  borderRadius: 8,
                  color: active ? '#111' : '#fff',
                  fontFamily: 'Arial, Helvetica, sans-serif',
                  fontWeight: 900,
                  fontSize: FONT_SIZE,
                  lineHeight: `${LINE_H - 8}px`,
                  WebkitTextStroke: active ? '0px' : '9px #000',
                  paintOrder: 'stroke fill',
                  transform: `scale(${active ? 0.7 + 0.3 * s : 1})`,
                }}
              >
                {w.text}
              </span>
            );
          })}
        </div>
      ))}
    </div>
  );
}
