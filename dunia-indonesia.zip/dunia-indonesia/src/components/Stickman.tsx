import type {CSSProperties} from 'react';
import type {Box} from '../data/layout';
import {lerp, wob} from '../lib/anim';

// Karakter utama mengikuti lembar referensi: kepala putih bulat, rambut cokelat tua
// berdiri berantakan, alis/mata hitam ekspresif, hoodie abu-abu muda, tangan & kaki hitam.

export type Expr =
  | 'neutral' | 'smug' | 'shock' | 'angry' | 'happy' | 'joy'
  | 'tired' | 'think' | 'confused' | 'panic' | 'awe';
export type Fx = 'sweat' | 'bang' | 'question' | 'swirl' | 'sparkle';

/** Sudut dalam derajat dari arah "lurus ke bawah"; positif = ke kanan layar. [paha/lengan atas, tekukan] */
export type Pose = {
  aL: [number, number];
  aR: [number, number];
  lL: [number, number];
  lR: [number, number];
  tilt: number;
  dy: number;
};

const P = (
  aL: [number, number], aR: [number, number], lL: [number, number], lR: [number, number], tilt = 0, dy = 0,
): Pose => ({aL, aR, lL, lR, tilt, dy});

export const POSES = {
  stand: P([-8, -4], [8, 4], [-4, 0], [4, 0]),
  hips: P([-40, 70], [40, -70], [-6, 0], [6, 0]),
  point: P([-8, -4], [100, 0], [-6, 0], [8, 0], -3),
  cheer: P([-155, 0], [155, 0], [-14, 10], [14, -10], 0, -10),
  hold: P([-8, -4], [60, 50], [-4, 0], [4, 0]),
  sit: P([-35, 40], [35, -40], [72, 15], [98, 5], 0, 205),
  think: P([-8, -4], [20, 180], [-4, 0], [4, 0], -2),
  panic: P([-140, -70], [140, 70], [-14, 6], [14, -6], 0, -6),
  chili: P([-8, -4], [165, 8], [-6, 0], [6, 0], -4),
  eat: P([-8, -4], [100, 150], [-6, 0], [6, 0], 2),
  wave: P([-8, -4], [150, 20], [-4, 0], [4, 0]),
  slump: P([-5, 8], [5, -8], [-4, 0], [4, 0], 6),
  wow: P([-100, 10], [100, -10], [-10, 0], [10, 0]),
} satisfies Record<string, Pose>;
export type PoseName = keyof typeof POSES;

const mix2 = (a: [number, number], b: [number, number], t: number): [number, number] => [lerp(a[0], b[0], t), lerp(a[1], b[1], t)];
export function blendPose(a: Pose, b: Pose, t: number): Pose {
  return {
    aL: mix2(a.aL, b.aL, t), aR: mix2(a.aR, b.aR, t), lL: mix2(a.lL, b.lL, t), lR: mix2(a.lR, b.lR, t),
    tilt: lerp(a.tilt, b.tilt, t), dy: lerp(a.dy, b.dy, t),
  };
}

const HOOD = '#D6D9E0';
const HOOD2 = '#BFC4CF';
const HAIR = '#4A2C1D';
const HAIR_HI = '#7A4B2E';
const INK = '#111';
const rad = (d: number) => (d * Math.PI) / 180;
const pt = (x: number, y: number, len: number, ang: number): [number, number] => [x + len * Math.sin(rad(ang)), y + len * Math.cos(rad(ang))];

function Arm({sx, sy, a}: {sx: number; sy: number; a: [number, number]}) {
  const [ex, ey] = pt(sx, sy, 62, a[0]);
  const [hx, hy] = pt(ex, ey, 92, a[0] + a[1]);
  return (
    <g strokeLinecap="round">
      <line x1={sx} y1={sy} x2={ex} y2={ey} stroke={INK} strokeWidth={58} />
      <line x1={sx} y1={sy} x2={ex} y2={ey} stroke={HOOD} strokeWidth={46} />
      <line x1={ex} y1={ey} x2={hx} y2={hy} stroke={INK} strokeWidth={15} />
      <circle cx={hx} cy={hy} r={17} fill={INK} />
    </g>
  );
}

function Leg({hx, hy, a}: {hx: number; hy: number; a: [number, number]}) {
  const [kx, ky] = pt(hx, hy, 98, a[0]);
  const [ax, ay] = pt(kx, ky, 102, a[0] + a[1]);
  const dir = Math.sin(rad(a[0] + a[1])) >= 0 ? 1 : -1;
  return (
    <g>
      <polyline points={`${hx},${hy} ${kx},${ky} ${ax},${ay}`} fill="none" stroke={INK} strokeWidth={15} strokeLinecap="round" strokeLinejoin="round" />
      <ellipse cx={ax + dir * 10} cy={ay + 6} rx={30} ry={13} fill={INK} />
    </g>
  );
}

const HAIR_PATH =
  'M110,152 L104,98 L138,112 L134,52 L168,88 L186,30 L210,82 L246,36 L250,92 L286,68 L274,122 L294,154 Q200,92 110,152 Z';

function Hair({back}: {back: boolean}) {
  if (back) {
    return (
      <g stroke={INK} strokeWidth={6} strokeLinejoin="round">
        <ellipse cx={200} cy={150} rx={94} ry={88} fill={HAIR} />
        <path d="M108,120 L96,70 L136,92 L134,40 L172,74 L190,18 L214,70 L250,26 L254,82 L292,56 L280,112 Z" fill={HAIR} />
        <path d="M200,60 L196,200 M160,80 L156,170 M240,80 L246,170" stroke={HAIR_HI} strokeWidth={5} fill="none" />
      </g>
    );
  }
  return (
    <g strokeLinejoin="round">
      <path d={HAIR_PATH} fill={HAIR} stroke={INK} strokeWidth={6} />
      <path d="M150,100 L158,66 M200,92 L200,50 M240,98 L244,60 M175,96 L180,60" stroke={HAIR_HI} strokeWidth={5} strokeLinecap="round" fill="none" />
    </g>
  );
}

const brow = (x1: number, y1: number, x2: number, y2: number) => (
  <line x1={x1} y1={y1} x2={x2} y2={y2} stroke={INK} strokeWidth={9} strokeLinecap="round" />
);
const dotEye = (cx: number, cy: number, rx = 10, ry = 13) => <ellipse cx={cx} cy={cy} rx={rx} ry={ry} fill={INK} />;
const bigEye = (cx: number, cy: number, r = 22, pr = 6) => (
  <g>
    <circle cx={cx} cy={cy} r={r} fill="#fff" stroke={INK} strokeWidth={5} />
    <circle cx={cx + 2} cy={cy + 2} r={pr} fill={INK} />
  </g>
);
const arcEye = (cx: number, cy: number) => (
  <path d={`M${cx - 15},${cy + 8} Q${cx},${cy - 16} ${cx + 15},${cy + 8}`} fill="none" stroke={INK} strokeWidth={8} strokeLinecap="round" />
);
const openMouth = (cx: number, cy: number, w: number, h: number) => (
  <g>
    <path d={`M${cx - w},${cy} Q${cx},${cy + 10} ${cx + w},${cy} Q${cx + w * 0.8},${cy + h} ${cx},${cy + h} Q${cx - w * 0.8},${cy + h} ${cx - w},${cy} Z`} fill="#B3262F" stroke={INK} strokeWidth={5} strokeLinejoin="round" />
    <ellipse cx={cx} cy={cy + h * 0.78} rx={w * 0.45} ry={h * 0.2} fill="#F27C86" />
  </g>
);
const blush = (
  <g fill="#F4A7B0" opacity={0.75}>
    <ellipse cx={140} cy={205} rx={16} ry={9} />
    <ellipse cx={260} cy={205} rx={16} ry={9} />
  </g>
);

function Face({expr}: {expr: Expr}) {
  switch (expr) {
    case 'smug':
      return (
        <g>
          {dotEye(165, 168, 11, 9)}{dotEye(235, 168, 11, 9)}
          <line x1={150} y1={160} x2={180} y2={160} stroke={INK} strokeWidth={7} strokeLinecap="round" />
          <line x1={220} y1={160} x2={250} y2={160} stroke={INK} strokeWidth={7} strokeLinecap="round" />
          {brow(140, 138, 186, 148)}{brow(214, 148, 260, 138)}
          <path d="M158,214 Q205,248 252,204" fill="none" stroke={INK} strokeWidth={7} strokeLinecap="round" />
        </g>
      );
    case 'shock':
      return (
        <g>
          {bigEye(160, 168)}{bigEye(240, 168)}
          {brow(136, 120, 184, 112)}{brow(216, 112, 264, 120)}
          <ellipse cx={200} cy={236} rx={20} ry={28} fill="#6B1A1A" stroke={INK} strokeWidth={5} />
        </g>
      );
    case 'angry':
      return (
        <g>
          {dotEye(165, 172, 10, 11)}{dotEye(235, 172, 10, 11)}
          {brow(136, 126, 188, 152)}{brow(212, 152, 264, 126)}
          <path d="M164,244 Q200,204 236,244 Z" fill="#B3262F" stroke={INK} strokeWidth={5} strokeLinejoin="round" />
        </g>
      );
    case 'happy':
      return (
        <g>
          {arcEye(162, 168)}{arcEye(238, 168)}
          {brow(142, 132, 184, 128)}{brow(216, 128, 258, 132)}
          {openMouth(200, 206, 48, 56)}
        </g>
      );
    case 'joy':
      return (
        <g>
          {arcEye(162, 166)}{arcEye(238, 166)}
          {brow(140, 128, 184, 120)}{brow(216, 120, 260, 128)}
          {openMouth(200, 202, 56, 66)}
          {blush}
        </g>
      );
    case 'tired':
      return (
        <g>
          <line x1={146} y1={172} x2={180} y2={172} stroke={INK} strokeWidth={8} strokeLinecap="round" />
          <line x1={220} y1={172} x2={254} y2={172} stroke={INK} strokeWidth={8} strokeLinecap="round" />
          <path d="M150,186 Q163,194 176,186 M224,186 Q237,194 250,186" fill="none" stroke="#9AA0AC" strokeWidth={4} />
          {brow(140, 146, 184, 138)}{brow(216, 138, 260, 146)}
          <path d="M168,236 Q200,214 232,236" fill="none" stroke={INK} strokeWidth={7} strokeLinecap="round" />
        </g>
      );
    case 'think':
      return (
        <g>
          {dotEye(168, 166, 9, 12)}{dotEye(238, 164, 9, 12)}
          {brow(140, 142, 186, 128)}{brow(214, 144, 262, 140)}
          <line x1={182} y1={228} x2={224} y2={222} stroke={INK} strokeWidth={7} strokeLinecap="round" />
        </g>
      );
    case 'confused':
      return (
        <g>
          {dotEye(164, 170, 10, 13)}{bigEye(238, 168, 17, 5)}
          {brow(140, 124, 186, 140)}{brow(216, 132, 262, 128)}
          <path d="M162,230 Q178,214 194,230 T226,230 T248,224" fill="none" stroke={INK} strokeWidth={7} strokeLinecap="round" />
        </g>
      );
    case 'panic':
      return (
        <g>
          {bigEye(160, 168, 25, 5)}{bigEye(240, 168, 25, 5)}
          {brow(134, 116, 184, 104)}{brow(216, 104, 266, 116)}
          {openMouth(200, 206, 42, 70)}
        </g>
      );
    case 'awe':
      return (
        <g>
          <circle cx={160} cy={168} r={23} fill="#fff" stroke={INK} strokeWidth={5} />
          <circle cx={240} cy={168} r={23} fill="#fff" stroke={INK} strokeWidth={5} />
          <circle cx={162} cy={170} r={11} fill={INK} />
          <circle cx={242} cy={170} r={11} fill={INK} />
          <circle cx={157} cy={164} r={4} fill="#fff" />
          <circle cx={237} cy={164} r={4} fill="#fff" />
          {brow(138, 124, 184, 118)}{brow(216, 118, 262, 124)}
          <ellipse cx={200} cy={232} rx={15} ry={19} fill="#6B1A1A" stroke={INK} strokeWidth={5} />
          {blush}
        </g>
      );
    default:
      return (
        <g>
          {dotEye(165, 168)}{dotEye(235, 168)}
          {brow(142, 140, 188, 138)}{brow(212, 138, 258, 140)}
          <line x1={176} y1={226} x2={224} y2={226} stroke={INK} strokeWidth={7} strokeLinecap="round" />
        </g>
      );
  }
}

const star = (cx: number, cy: number, r: number, key: string) => (
  <path key={key} d={`M${cx},${cy - r} L${cx + r * 0.28},${cy - r * 0.28} L${cx + r},${cy} L${cx + r * 0.28},${cy + r * 0.28} L${cx},${cy + r} L${cx - r * 0.28},${cy + r * 0.28} L${cx - r},${cy} L${cx - r * 0.28},${cy - r * 0.28} Z`} fill="#FFC928" stroke={INK} strokeWidth={3} />
);

function FxLayer({fx, f}: {fx: Fx[]; f: number}) {
  const bounce = wob(f, 10, 4);
  return (
    <g>
      {fx.includes('bang') && (
        <g transform={`translate(0 ${bounce})`}>
          <path d="M318,40 L352,70 M330,22 L372,40" stroke="#FFC928" strokeWidth={14} strokeLinecap="round" />
          <text x={300} y={118} fontSize={96} fontWeight={900} fontFamily="Arial, sans-serif" fill="#E53935" stroke={INK} strokeWidth={4}>!</text>
        </g>
      )}
      {fx.includes('question') && (
        <text x={296} y={96 + bounce} fontSize={110} fontWeight={900} fontFamily="Arial, sans-serif" fill={INK}>?</text>
      )}
      {fx.includes('sweat') && (
        <g fill="#6EC6FF" stroke={INK} strokeWidth={3}>
          <path d="M82,120 Q70,150 82,162 Q94,150 82,120 Z" transform={`translate(0 ${(f % 24) * 0.8})`} />
          <path d="M330,150 Q320,176 330,186 Q340,176 330,150 Z" transform={`translate(0 ${((f + 12) % 24) * 0.8})`} />
        </g>
      )}
      {fx.includes('swirl') && (
        <path d="M316,66 q22,-26 44,-4 q16,24 -8,34 q-20,6 -24,-12" fill="none" stroke="#8C93A3" strokeWidth={6} strokeLinecap="round" transform={`rotate(${f * 6} 338 80)`} />
      )}
      {fx.includes('sparkle') && (
        <g>
          {star(330 + wob(f, 20, 4), 60, 22, 'a')}
          {star(70, 90 + wob(f, 16, 4, 0.3), 16, 'b')}
          {star(344, 220, 12, 'c')}
        </g>
      )}
    </g>
  );
}

export type StickmanProps = {
  box: Box;
  expr?: Expr;
  pose?: Pose;
  f?: number;
  view?: 'full' | 'head' | 'half';
  vb?: string;
  flip?: boolean;
  back?: boolean;
  fx?: Fx[];
  scale?: number;
  rot?: number;
  offsetX?: number;
  offsetY?: number;
  shake?: number;
  style?: CSSProperties;
};

const VIEWS = {full: '-60 0 520 700', half: '-60 0 520 520', head: '40 20 320 300'};

export function Stickman({
  box, expr = 'neutral', pose = POSES.stand, f = 0, view = 'full', vb, flip = false, back = false,
  fx = [], scale = 1, rot = 0, offsetX = 0, offsetY = 0, shake = 0, style,
}: StickmanProps) {
  const bob = wob(f, 28, 3);
  const dx = offsetX + (shake ? wob(f, 2.4, shake) : 0);
  const dy = offsetY + (shake ? wob(f, 3.1, shake * 0.6, 0.25) : 0);
  const viewBox = vb ?? VIEWS[view];
  return (
    <div
      style={{
        position: 'absolute',
        left: box.x,
        top: box.y,
        width: box.w,
        height: box.h,
        transformOrigin: '50% 100%',
        transform: `translate(${dx}px, ${dy}px) scale(${flip ? -scale : scale}, ${scale}) rotate(${rot}deg)`,
        ...style,
      }}
    >
      <svg width="100%" height="100%" viewBox={viewBox} preserveAspectRatio="xMidYMax meet" style={{overflow: 'visible'}}>
        <ellipse cx={200} cy={678} rx={118} ry={14} fill="rgba(0,0,0,0.2)" />
        <g transform={`translate(0 ${pose.dy + bob}) rotate(${pose.tilt} 200 458)`}>
          <Leg hx={172} hy={458} a={pose.lL} />
          <Leg hx={228} hy={458} a={pose.lR} />
          {/* hoodie */}
          <g stroke={INK} strokeWidth={6} strokeLinejoin="round">
            <path d="M120,262 Q200,236 280,262 L294,302 L298,452 Q200,478 102,452 L106,302 Z" fill={HOOD} />
            {back ? (
              <ellipse cx={200} cy={268} rx={74} ry={30} fill={HOOD2} />
            ) : (
              <g>
                <ellipse cx={200} cy={262} rx={38} ry={16} fill={INK} />
                <path d="M126,262 Q200,306 274,262 Q264,246 200,242 Q136,246 126,262 Z" fill={HOOD2} />
                <path d="M140,396 Q200,380 260,396 L270,446 Q200,462 130,446 Z" fill="#CBCFD9" strokeWidth={4} />
              </g>
            )}
          </g>
          {!back && (
            <g stroke="#8E93A1" strokeWidth={5} strokeLinecap="round">
              <line x1={184} y1={288} x2={182} y2={346} />
              <line x1={216} y1={288} x2={218} y2={346} />
            </g>
          )}
          <Arm sx={112} sy={285} a={pose.aL} />
          <Arm sx={288} sy={285} a={pose.aR} />
          {/* kepala */}
          <circle cx={200} cy={160} r={92} fill="#fff" stroke={INK} strokeWidth={7} />
          {back ? null : <Face expr={expr} />}
          <Hair back={back} />
          {back ? null : <FxLayer fx={fx} f={f} />}
        </g>
      </svg>
    </div>
  );
}
