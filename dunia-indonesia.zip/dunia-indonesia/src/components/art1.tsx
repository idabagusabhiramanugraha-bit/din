import type {CSSProperties, ReactNode} from 'react';
import type {Box} from '../data/layout';
import {rng, wob} from '../lib/anim';

export const INK = '#111';
export const RED = '#E70011';

export function Abs({box, children, style}: {box: Box; children: ReactNode; style?: CSSProperties}) {
  return (
    <div style={{position: 'absolute', left: box.x, top: box.y, width: box.w, height: box.h, ...style}}>{children}</div>
  );
}

/** Sinar komik berputar (latar). */
export function Burst({box, f, a = '#FFE9A8', b = '#FFD36B', n = 20, speed = 0.004}: {
  box: Box; f: number; a?: string; b?: string; n?: number; speed?: number;
}) {
  const R = 1600;
  const wedges = [];
  for (let i = 0; i < n; i++) {
    const a0 = (i * 2 * Math.PI) / n + f * speed;
    const a1 = a0 + Math.PI / n;
    wedges.push(
      <path key={i} d={`M0,0 L${R * Math.cos(a0)},${R * Math.sin(a0)} L${R * Math.cos(a1)},${R * Math.sin(a1)} Z`} fill={i % 2 ? a : b} />,
    );
  }
  return (
    <Abs box={box}>
      <svg width="100%" height="100%" viewBox={`${-box.w / 2} ${-box.h / 2} ${box.w} ${box.h}`}>{wedges}</svg>
    </Abs>
  );
}

export function Cloud({x, y, s = 1, fill = '#fff'}: {x: number; y: number; s?: number; fill?: string}) {
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`} fill={fill} stroke={INK} strokeWidth={5}>
      <path d="M0,60 Q-10,20 30,22 Q40,-18 90,0 Q130,-14 140,30 Q180,34 170,64 Z" />
    </g>
  );
}

export function Star4({x, y, r, fill = '#FFC928'}: {x: number; y: number; r: number; fill?: string}) {
  return (
    <path
      d={`M${x},${y - r} L${x + r * 0.28},${y - r * 0.28} L${x + r},${y} L${x + r * 0.28},${y + r * 0.28} L${x},${y + r} L${x - r * 0.28},${y + r * 0.28} L${x - r},${y} L${x - r * 0.28},${y - r * 0.28} Z`}
      fill={fill}
      stroke={INK}
      strokeWidth={3}
    />
  );
}

/** Garis kecepatan radial dari sebuah titik (deterministik). */
export function SpeedLines({box, f, cx, cy, n = 28, seed = 11, color = '#111', inner = 0.35}: {
  box: Box; f: number; cx: number; cy: number; n?: number; seed?: number; color?: string; inner?: number;
}) {
  const r = rng(seed);
  const lines = [];
  for (let i = 0; i < n; i++) {
    const ang = (i / n) * Math.PI * 2 + r() * 0.1;
    const len0 = box.w * (inner + r() * 0.15);
    const len1 = len0 + 120 + r() * 220;
    const jitter = wob(f + i * 3, 6, 14);
    lines.push(
      <line key={i} x1={cx + Math.cos(ang) * (len0 + jitter)} y1={cy + Math.sin(ang) * (len0 + jitter)}
        x2={cx + Math.cos(ang) * len1} y2={cy + Math.sin(ang) * len1} stroke={color} strokeWidth={4 + r() * 6} strokeLinecap="round" />,
    );
  }
  return (
    <Abs box={box}>
      <svg width="100%" height="100%" viewBox={`0 0 ${box.w} ${box.h}`} style={{overflow: 'hidden'}}>{lines}</svg>
    </Abs>
  );
}

// ---------------------------------------------------------------- Bumi -----
export function Earth({box, f = 0, flag = 0, wave = 0, id = 'e'}: {box: Box; f?: number; flag?: number; wave?: number; id?: string}) {
  const shift = (f * 0.18) % 100;
  const edge = (y: number) => Array.from({length: 21}, (_, i) => [i * 5, y + Math.sin(i * 0.7 + wave * 0.2) * 2.6] as [number, number]);
  const pts = (a: Array<[number, number]>) => a.map((p) => p.join(',')).join(' ');
  const top = edge(26);
  const mid = edge(50);
  const bot = edge(74);
  const red = pts([...top, ...[...mid].reverse()]);
  const white = pts([...mid, ...[...bot].reverse()]);
  const land = (
    <g fill="#5DBB63" stroke={INK} strokeWidth={1.2}>
      <path d="M12,34 Q22,20 38,26 Q46,34 38,46 Q28,54 16,48 Z" />
      <path d="M52,22 Q68,16 80,28 Q86,40 74,46 Q60,44 54,34 Z" />
      <path d="M40,58 Q54,54 62,66 Q58,82 46,86 Q36,78 40,58 Z" />
      <path d="M72,60 Q86,58 90,70 Q84,80 74,76 Z" />
    </g>
  );
  return (
    <Abs box={box}>
      <svg width="100%" height="100%" viewBox="0 0 100 100" style={{overflow: 'visible'}}>
        <defs>
          <clipPath id={`${id}-c`}><circle cx={50} cy={50} r={46} /></clipPath>
          <clipPath id={`${id}-r`}><rect x={-20} y={0} width={Math.max(0.01, flag * 150)} height={100} /></clipPath>
        </defs>
        <circle cx={50} cy={50} r={50} fill="rgba(120,200,255,0.35)" />
        <circle cx={50} cy={50} r={46} fill="#3FA0F0" stroke={INK} strokeWidth={2.4} />
        <g clipPath={`url(#${id}-c)`}>
          <g transform={`translate(${-shift} 0)`}>{land}</g>
          <g transform={`translate(${100 - shift} 0)`}>{land}</g>
          <ellipse cx={34} cy={30} rx={20} ry={12} fill="#fff" opacity={0.22} />
          <path d="M96,50 A46,46 0 0 1 20,86 A52,52 0 0 0 96,50 Z" fill="#000" opacity={0.16} />
          <g clipPath={`url(#${id}-r)`}>
            <g transform="rotate(-10 50 50)">
              <polygon points={red} fill={RED} stroke={INK} strokeWidth={1.2} />
              <polygon points={white} fill="#fff" stroke={INK} strokeWidth={1.2} />
            </g>
          </g>
        </g>
      </svg>
    </Abs>
  );
}

// ------------------------------------------------------------- Manusia -----
const SKINS = ['#FFE0BD', '#F1C27D', '#C68642', '#8D5524', '#FFFFFF', '#E0AC69'];
const SHIRTS = ['#E53935', '#FDD835', '#43A047', '#1E88E5', '#FB8C00', '#EC407A', '#26A69A', '#FFFFFF'];
const GRAYS = ['#9E9E9E', '#BDBDBD', '#757575', '#E0E0E0', '#8D8D8D'];
const HAIRS = ['#2B1B12', '#111', '#5D3A1A', '#C9A227', '#7B3F00'];

export function Person({x, y, s = 1, shirt, skin = '#fff', hair = '#2B1B12', wow = false, wave = 0}: {
  x: number; y: number; s?: number; shirt: string; skin?: string; hair?: string; wow?: boolean; wave?: number;
}) {
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      <line x1={-6} y1={74} x2={-8} y2={104} stroke={INK} strokeWidth={6} strokeLinecap="round" />
      <line x1={6} y1={74} x2={8} y2={104} stroke={INK} strokeWidth={6} strokeLinecap="round" />
      <line x1={-14} y1={40} x2={-26} y2={66 + wave} stroke={INK} strokeWidth={6} strokeLinecap="round" />
      <line x1={14} y1={40} x2={26} y2={66 - wave} stroke={INK} strokeWidth={6} strokeLinecap="round" />
      <rect x={-15} y={32} width={30} height={46} rx={9} fill={shirt} stroke={INK} strokeWidth={4.5} />
      <circle cx={0} cy={14} r={21} fill={skin} stroke={INK} strokeWidth={4.5} />
      <path d="M-21,10 Q-20,-9 0,-9 Q20,-9 21,10 Q8,1 -21,10 Z" fill={hair} stroke={INK} strokeWidth={3} />
      <circle cx={-7} cy={14} r={2.8} fill={INK} />
      <circle cx={7} cy={14} r={2.8} fill={INK} />
      {wow ? <ellipse cx={0} cy={25} rx={4} ry={5} fill={INK} /> : <path d="M-6,24 Q0,29 6,24" fill="none" stroke={INK} strokeWidth={3} strokeLinecap="round" />}
    </g>
  );
}

/** Kerumunan berperspektif: baris jauh kecil di atas, baris dekat besar di bawah. */
export function Crowd({box, f, seed = 3, mono = false, rows = 9, wowChance = 0.22}: {
  box: Box; f: number; seed?: number; mono?: boolean; rows?: number; wowChance?: number;
}) {
  const r = rng(seed);
  const items: ReactNode[] = [];
  for (let row = 0; row < rows; row++) {
    const d = row / (rows - 1);
    const s = 0.34 + Math.pow(d, 1.7) * 1.5;
    const y = 80 + Math.pow(d, 1.45) * (box.h - 330);
    const step = 62 * s;
    const n = Math.ceil(box.w / step) + 2;
    const off = r() * step;
    for (let i = 0; i < n; i++) {
      const jit = (r() - 0.5) * step * 0.5;
      const shirt = mono ? GRAYS[Math.floor(r() * GRAYS.length)] : SHIRTS[Math.floor(r() * SHIRTS.length)];
      const skin = mono ? '#F2F2F2' : SKINS[Math.floor(r() * SKINS.length)];
      const hair = HAIRS[Math.floor(r() * HAIRS.length)];
      const wow = r() < wowChance;
      const x = i * step - off + jit + wob(f + i * 7 + row * 3, 40, 2 * s);
      items.push(<Person key={`${row}-${i}`} x={x} y={y + wob(f + i * 5, 22, 3 * s)} s={s} shirt={shirt} skin={skin} hair={hair} wow={wow} />);
    }
  }
  return (
    <Abs box={box}>
      <svg width="100%" height="100%" viewBox={`0 0 ${box.w} ${box.h}`} style={{overflow: 'hidden'}}>{items}</svg>
    </Abs>
  );
}

/** Antrean memanjang menuju titik hilang (vp dalam koordinat kanvas). */
export function Queue({box, f, vp, seed = 5, count = 44}: {box: Box; f: number; vp: [number, number]; seed?: number; count?: number}) {
  const r = rng(seed);
  const vx = vp[0] - box.x;
  const vy = vp[1] - box.y;
  const lanes = [-1.7, -0.6, 0.55, 1.65];
  const items: ReactNode[] = [];
  for (let n = 0; n < count; n++) {
    const k = n / (count - 1);
    const s = 0.2 + Math.pow(k, 2.1) * 1.5;
    const ground = vy + Math.pow(k, 1.7) * (box.h - vy - 20);
    for (let li = 0; li < lanes.length; li++) {
      const sway = wob(f + n * 9 + li * 17, 36, 3 * s);
      items.push(
        <Person key={`${n}-${li}`} x={vx + lanes[li] * 95 * s + (r() - 0.5) * 18 * s + sway} y={ground - 104 * s} s={s}
          shirt={GRAYS[Math.floor(r() * GRAYS.length)]} skin="#F2F2F2" hair="#444" wow={r() < 0.15} />,
      );
    }
  }
  return (
    <Abs box={box}>
      <svg width="100%" height="100%" viewBox={`0 0 ${box.w} ${box.h}`} style={{overflow: 'hidden'}}>
        <polygon points={`${vx - 14},${vy} ${vx + 14},${vy} ${box.w + 260},${box.h} ${-260},${box.h}`} fill="#8C8C8C" stroke={INK} strokeWidth={5} />
        <line x1={vx} y1={vy} x2={vx} y2={box.h} stroke="#D8D8D8" strokeWidth={6} strokeDasharray="40 36" strokeDashoffset={-f * 3} />
        {items}
      </svg>
    </Abs>
  );
}
