import type {ReactNode} from 'react';
import type {Box} from '../data/layout';
import {clamp, fmtDots, rng, wob} from '../lib/anim';
import {Abs, INK, RED, Star4} from './art1';

const FONT = '"Arial Black", Impact, Arial, sans-serif';

// ----------------------------------------------------------------- KTP -----
export function KtpCard({box, f}: {box: Box; f: number}) {
  const sx = ((f * 6) % 700) - 200;
  return (
    <Abs box={box}>
      <svg width="100%" height="100%" viewBox="0 0 340 220" style={{overflow: 'visible'}}>
        <defs>
          <clipPath id="ktp-c"><rect x={0} y={0} width={340} height={220} rx={16} /></clipPath>
        </defs>
        <rect x={6} y={8} width={340} height={220} rx={16} fill="rgba(0,0,0,0.25)" />
        <rect x={0} y={0} width={340} height={220} rx={16} fill="#BFE3FF" stroke={INK} strokeWidth={6} />
        <g clipPath="url(#ktp-c)">
          <rect x={0} y={0} width={340} height={46} fill="#2E86DE" />
          <text x={16} y={32} fontSize={22} fontWeight={900} fontFamily={FONT} fill="#fff">KARTU TANDA PENDUDUK</text>
          <rect x={286} y={56} width={40} height={14} fill={RED} stroke={INK} strokeWidth={2} />
          <rect x={286} y={70} width={40} height={14} fill="#fff" stroke={INK} strokeWidth={2} />
          {[0, 1, 2, 3].map((i) => (
            <rect key={i} x={18} y={64 + i * 30} width={150 + (i % 2) * 40} height={14} rx={4} fill="#fff" stroke={INK} strokeWidth={2} />
          ))}
          <rect x={218} y={96} width={92} height={100} rx={8} fill="#fff" stroke={INK} strokeWidth={4} />
          <circle cx={264} cy={134} r={22} fill="#fff" stroke={INK} strokeWidth={4} />
          <path d="M244,128 L248,112 L258,122 L264,106 L272,120 L282,110 L284,128 Z" fill="#4A2C1D" stroke={INK} strokeWidth={2} />
          <circle cx={257} cy={138} r={2.5} fill={INK} />
          <circle cx={271} cy={138} r={2.5} fill={INK} />
          <rect x={242} y={162} width={44} height={30} rx={8} fill="#D6D9E0" stroke={INK} strokeWidth={3} />
          <text x={18} y={206} fontSize={15} fontWeight={900} fontFamily={FONT} fill={INK}>NIK 8.000.000.000</text>
          <polygon points={`${sx},0 ${sx + 50},0 ${sx + 10},220 ${sx - 40},220`} fill="#fff" opacity={0.5} />
        </g>
      </svg>
    </Abs>
  );
}

// ---------------------------------------------------------- Peta dunia -----
export function WorldMap({box, f, grow = 0}: {box: Box; f: number; grow?: number}) {
  const land = '#D5D5D5';
  const shake = (k: number) => `translate(${wob(f + k * 5, 4, 2.2)} ${wob(f + k * 7, 5, 1.6)})`;
  const conts = [
    'M120,150 Q220,90 330,130 Q390,170 360,250 Q330,300 270,330 Q230,380 200,330 Q150,280 110,230 Z',
    'M300,400 Q370,380 400,440 Q410,540 350,640 Q320,660 305,600 Q280,500 300,400 Z',
    'M470,150 Q540,110 620,140 Q650,190 600,215 Q540,230 480,205 Z',
    'M500,260 Q580,240 650,290 Q690,360 640,470 Q600,560 560,540 Q520,460 500,380 Q470,310 500,260 Z',
    'M640,130 Q780,80 960,140 Q1030,200 990,270 Q930,330 860,320 Q760,300 690,270 Q630,210 640,130 Z',
    'M880,520 Q960,490 1020,540 Q1030,600 960,620 Q890,610 870,570 Z',
  ];
  const islands: Array<[number, number, number, number, number]> = [
    [760, 410, 55, 14, 35], [820, 470, 50, 10, 0], [850, 420, 34, 30, 0], [912, 430, 16, 28, 0], [990, 455, 48, 22, -10],
  ];
  const gs = 1 + grow * 0.9;
  return (
    <Abs box={box}>
      <svg width="100%" height="100%" viewBox="0 0 1080 760" style={{overflow: 'hidden'}}>
        <rect x={0} y={0} width={1080} height={760} fill="#9ADBF5" />
        {[0, 1, 2, 3, 4].map((i) => (
          <line key={i} x1={0} y1={90 + i * 150} x2={1080} y2={90 + i * 150} stroke="#fff" strokeWidth={3} opacity={0.5} />
        ))}
        {conts.map((d, i) => (
          <path key={i} d={d} fill={land} stroke={INK} strokeWidth={6} strokeLinejoin="round" transform={shake(i)} />
        ))}
        <g transform={`translate(840 440) scale(${gs}) translate(-840 -440)`}>
          <circle cx={850} cy={430} r={190} fill="#FFD400" opacity={0.35 * grow} />
          {islands.map(([cx, cy, rx, ry, rot], i) => (
            <ellipse key={i} cx={cx} cy={cy} rx={rx} ry={ry} transform={`rotate(${rot} ${cx} ${cy})`} fill={RED} stroke={INK} strokeWidth={5} />
          ))}
          <g transform={`translate(850 ${340 - grow * 10})`}>
            <path d="M-34,0 L-34,-34 L-17,-14 L0,-40 L17,-14 L34,-34 L34,0 Z" fill="#FFC928" stroke={INK} strokeWidth={5} strokeLinejoin="round" />
          </g>
        </g>
      </svg>
    </Abs>
  );
}

// ----------------------------------------------------------- Timbangan -----
export function Scale({box, tilt, f}: {box: Box; tilt: number; f: number}) {
  const th = (tilt * Math.PI) / 180;
  const L = 165;
  const cx = 275;
  const cy = 190;
  const lx = cx - L * Math.cos(th);
  const ly = cy - L * Math.sin(th);
  const rx = cx + L * Math.cos(th);
  const ry = cy + L * Math.sin(th);
  const pan = (x: number, y: number, children: ReactNode) => (
    <g>
      <line x1={x} y1={y} x2={x - 70} y2={y + 150} stroke={INK} strokeWidth={5} />
      <line x1={x} y1={y} x2={x + 70} y2={y + 150} stroke={INK} strokeWidth={5} />
      <path d={`M${x - 100},${y + 150} L${x + 100},${y + 150} Q${x + 90},${y + 196} ${x},${y + 200} Q${x - 90},${y + 196} ${x - 100},${y + 150} Z`} fill="#C9A227" stroke={INK} strokeWidth={6} />
      {children}
    </g>
  );
  const bob = wob(f, 30, 2);
  return (
    <Abs box={box}>
      <svg width="100%" height="100%" viewBox="0 0 550 700" style={{overflow: 'visible'}}>
        <path d="M200,690 L350,690 L310,630 L240,630 Z" fill="#8D6E63" stroke={INK} strokeWidth={6} strokeLinejoin="round" />
        <rect x={262} y={190} width={26} height={444} fill="#A1887F" stroke={INK} strokeWidth={6} />
        {pan(lx, ly, (
          <g transform={`translate(${lx} ${ly + 150 + bob})`}>
            {[[-58, -20, '#5DBB63'], [-10, -34, '#F4B942'], [38, -18, '#E57373'], [-30, -62, '#4FC3F7'], [24, -58, '#BA68C8']].map(([x, y, c], i) => (
              <ellipse key={i} cx={x as number} cy={y as number} rx={30} ry={20} fill={c as string} stroke={INK} strokeWidth={4} />
            ))}
          </g>
        ))}
        {pan(rx, ry, (
          <g transform={`translate(${rx} ${ry + 150 + bob})`}>
            <rect x={-80} y={-130} width={160} height={130} rx={10} fill={RED} stroke={INK} strokeWidth={6} />
            <rect x={-80} y={-65} width={160} height={65} rx={0} fill="#fff" stroke={INK} strokeWidth={6} />
          </g>
        ))}
        <line x1={lx} y1={ly} x2={rx} y2={ry} stroke={INK} strokeWidth={20} strokeLinecap="round" />
        <line x1={lx} y1={ly} x2={rx} y2={ry} stroke="#C9A227" strokeWidth={10} strokeLinecap="round" />
        <circle cx={cx} cy={cy} r={22} fill="#C9A227" stroke={INK} strokeWidth={6} />
      </svg>
    </Abs>
  );
}

// ------------------------------------------------------------ Gedung -------
export function Dukcapil({box, f}: {box: Box; f: number}) {
  const flagWave = (i: number) => Math.sin((f + i * 6) / 7) * 3;
  const pts = Array.from({length: 9}, (_, i) => `${i * 10},${flagWave(i)}`).join(' ');
  return (
    <Abs box={box}>
      <svg width="100%" height="100%" viewBox="0 0 1080 520" style={{overflow: 'hidden'}}>
        <rect x={0} y={0} width={1080} height={520} fill="#BFE7F5" />
        <rect x={60} y={90} width={960} height={430} fill="#EFE3C8" stroke={INK} strokeWidth={7} />
        <rect x={30} y={60} width={1020} height={50} fill="#C9B88F" stroke={INK} strokeWidth={7} />
        <rect x={290} y={120} width={500} height={90} rx={8} fill="#1565C0" stroke={INK} strokeWidth={7} />
        <text x={540} y={188} textAnchor="middle" fontSize={72} fontWeight={900} fontFamily={FONT} fill="#FFD400" stroke={INK} strokeWidth={2}>DUKCAPIL</text>
        {Array.from({length: 4}).map((_, i) => (
          <g key={i}>
            <rect x={100 + i * 60} y={240} width={40} height={200} fill="#fff" stroke={INK} strokeWidth={5} />
            <rect x={840 + i * 50} y={240} width={34} height={200} fill="#fff" stroke={INK} strokeWidth={5} />
          </g>
        ))}
        <rect x={430} y={300} width={220} height={220} fill="#6D4C41" stroke={INK} strokeWidth={7} />
        <line x1={540} y1={300} x2={540} y2={520} stroke={INK} strokeWidth={5} />
        <circle cx={520} cy={420} r={7} fill="#FFD400" />
        <circle cx={560} cy={420} r={7} fill="#FFD400" />
        <line x1={70} y1={60} x2={70} y2={-20} stroke={INK} strokeWidth={6} />
        <g transform="translate(76 -18)">
          <polygon points={pts + ' 80,36 0,36'} fill={RED} stroke={INK} strokeWidth={3} />
        </g>
      </svg>
    </Abs>
  );
}

export function Clock({box, t}: {box: Box; t: number}) {
  const min = t * 18;
  const hr = t * 1.5;
  const hand = (deg: number, len: number, w: number) => (
    <line x1={100} y1={100} x2={100 + len * Math.sin((deg * Math.PI) / 180)} y2={100 - len * Math.cos((deg * Math.PI) / 180)} stroke={INK} strokeWidth={w} strokeLinecap="round" />
  );
  return (
    <Abs box={box}>
      <svg width="100%" height="100%" viewBox="0 0 200 200" style={{overflow: 'visible'}}>
        <circle cx={100} cy={100} r={92} fill="#fff" stroke={INK} strokeWidth={9} />
        {Array.from({length: 12}).map((_, i) => {
          const a = (i * 30 * Math.PI) / 180;
          return <line key={i} x1={100 + 76 * Math.sin(a)} y1={100 - 76 * Math.cos(a)} x2={100 + 86 * Math.sin(a)} y2={100 - 86 * Math.cos(a)} stroke={INK} strokeWidth={i % 3 === 0 ? 7 : 4} />;
        })}
        {hand(hr, 46, 9)}
        {hand(min, 68, 6)}
        <circle cx={100} cy={100} r={8} fill={RED} stroke={INK} strokeWidth={3} />
      </svg>
    </Abs>
  );
}

export function Ticket({box, f}: {box: Box; f: number}) {
  return (
    <Abs box={box} style={{transform: `rotate(${wob(f, 40, 4) - 8}deg)`}}>
      <svg width="100%" height="100%" viewBox="0 0 220 300" style={{overflow: 'visible'}}>
        <rect x={10} y={10} width={200} height={280} rx={12} fill="#FFF8C4" stroke={INK} strokeWidth={6} />
        <text x={110} y={60} textAnchor="middle" fontSize={26} fontWeight={900} fontFamily={FONT} fill={INK}>ANTREAN</text>
        <text x={110} y={150} textAnchor="middle" fontSize={64} fontWeight={900} fontFamily={FONT} fill={RED}>No.</text>
        <text x={110} y={225} textAnchor="middle" fontSize={34} fontWeight={900} fontFamily={FONT} fill={INK}>8.000.000.000</text>
        <line x1={30} y1={250} x2={190} y2={250} stroke={INK} strokeWidth={4} strokeDasharray="8 8" />
      </svg>
    </Abs>
  );
}

// ------------------------------------------------------------ Makanan ------
function Steam({x, y, f, seed}: {x: number; y: number; f: number; seed: number}) {
  const r = rng(seed);
  return (
    <g fill="none" stroke="#fff" strokeWidth={7} strokeLinecap="round" opacity={0.85}>
      {[0, 1, 2].map((i) => {
        const o = (f * 1.2 + i * 14 + r() * 20) % 60;
        const sx = x + (i - 1) * 24;
        return <path key={i} d={`M${sx},${y - o} q-14,-18 0,-34 q14,-18 0,-34`} opacity={1 - o / 70} />;
      })}
    </g>
  );
}

export function FoodTable({box, f}: {box: Box; f: number}) {
  return (
    <Abs box={box}>
      <svg width="100%" height="100%" viewBox="0 0 1080 700" style={{overflow: 'hidden'}}>
        <polygon points="0,40 1080,40 1080,700 0,700" fill="#B97A3E" />
        {Array.from({length: 9}).map((_, i) => (
          <line key={i} x1={0} y1={40 + i * 82} x2={1080} y2={40 + i * 82} stroke="#8E5A28" strokeWidth={6} />
        ))}
        <line x1={0} y1={40} x2={1080} y2={40} stroke={INK} strokeWidth={8} />
        {/* nasi goreng */}
        <ellipse cx={300} cy={300} rx={210} ry={84} fill="#fff" stroke={INK} strokeWidth={7} />
        <path d="M130,296 Q170,170 300,172 Q430,170 470,296 Q300,350 130,296 Z" fill="#D9A441" stroke={INK} strokeWidth={6} />
        {[[200, 260], [250, 230], [330, 240], [390, 270], [300, 290], [230, 300]].map(([x, y], i) => (
          <ellipse key={i} cx={x} cy={y} rx={12} ry={5} fill="#A9742A" transform={`rotate(${i * 30} ${x} ${y})`} />
        ))}
        <ellipse cx={310} cy={196} rx={56} ry={26} fill="#fff" stroke={INK} strokeWidth={5} />
        <circle cx={310} cy={194} r={14} fill="#FFC107" stroke={INK} strokeWidth={4} />
        <Steam x={300} y={170} f={f} seed={1} />
        {/* rendang */}
        <ellipse cx={790} cy={270} rx={200} ry={80} fill="#fff" stroke={INK} strokeWidth={7} />
        <ellipse cx={790} cy={268} rx={160} ry={58} fill="#7A3E1A" stroke={INK} strokeWidth={5} />
        {[[720, 262], [780, 250], [850, 266], [800, 286], [740, 288]].map(([x, y], i) => (
          <rect key={i} x={x - 24} y={y - 16} width={48} height={32} rx={9} fill="#4E2410" stroke={INK} strokeWidth={4} transform={`rotate(${i * 22 - 20} ${x} ${y})`} />
        ))}
        <ellipse cx={822} cy={246} rx={14} ry={5} fill={RED} />
        <Steam x={790} y={236} f={f} seed={2} />
        {/* sambal */}
        <ellipse cx={520} cy={520} rx={130} ry={52} fill="#E0E0E0" stroke={INK} strokeWidth={7} />
        <ellipse cx={520} cy={508} rx={104} ry={36} fill="#D32F2F" stroke={INK} strokeWidth={5} />
        {[[480, 506], [540, 500], [520, 520], [570, 516]].map(([x, y], i) => (
          <circle key={i} cx={x} cy={y} r={7} fill="#FF8A80" />
        ))}
        {/* mi instan */}
        <ellipse cx={850} cy={560} rx={160} ry={64} fill="#fff" stroke={INK} strokeWidth={7} />
        <ellipse cx={850} cy={552} rx={130} ry={46} fill="#FFD54F" stroke={INK} strokeWidth={5} />
        {Array.from({length: 7}).map((_, i) => (
          <path key={i} d={`M${760 + i * 26},${540 + (i % 2) * 14} q10,-18 22,0 t22,6`} fill="none" stroke="#F9A825" strokeWidth={6} strokeLinecap="round" />
        ))}
        <rect x={800} y={510} width={90} height={26} rx={6} fill="#C62828" stroke={INK} strokeWidth={4} transform="rotate(-8 845 523)" />
        <Steam x={850} y={520} f={f} seed={3} />
      </svg>
    </Abs>
  );
}

export function Bunting({box, f}: {box: Box; f: number}) {
  const flags = Array.from({length: 11}, (_, i) => i);
  return (
    <Abs box={box}>
      <svg width="100%" height="100%" viewBox="0 0 1080 200" style={{overflow: 'hidden'}}>
        <rect x={0} y={0} width={1080} height={200} fill="#FFE9A8" />
        <rect x={0} y={0} width={1080} height={200} fill="none" />
        <path d="M-20,20 Q540,120 1100,20" fill="none" stroke={INK} strokeWidth={6} />
        {flags.map((i) => {
          const x = 20 + i * 100;
          const y = 20 + Math.sin((i / 10) * Math.PI) * 78;
          return (
            <polygon key={i} points={`${x},${y} ${x + 64},${y + wob(f + i * 4, 30, 3)} ${x + 32},${y + 58}`} fill={i % 2 ? '#fff' : RED} stroke={INK} strokeWidth={5} strokeLinejoin="round" />
          );
        })}
        <text x={540} y={188} textAnchor="middle" fontSize={36} fontWeight={900} fontFamily={FONT} fill={INK}>WARUNG NUSANTARA</text>
      </svg>
    </Abs>
  );
}

export function Chili({box, f, angle = 0, glow = 0}: {box: Box; f: number; angle?: number; glow?: number}) {
  return (
    <Abs box={box} style={{transform: `rotate(${angle + wob(f, 36, 3)}deg)`}}>
      <svg width="100%" height="100%" viewBox="0 0 100 200" style={{overflow: 'visible'}}>
        {glow > 0 && <circle cx={50} cy={100} r={90} fill="#FFD400" opacity={0.35 * glow} />}
        <path d="M48,24 C72,34 86,80 76,130 C70,166 50,188 26,198 C46,160 46,130 40,96 C34,64 38,40 48,24 Z" fill={RED} stroke={INK} strokeWidth={5} strokeLinejoin="round" />
        <path d="M44,28 Q38,8 52,2 Q50,16 58,30 Z" fill="#2E9E3E" stroke={INK} strokeWidth={4} strokeLinejoin="round" />
        <path d="M56,50 Q70,86 64,122" fill="none" stroke="#fff" strokeWidth={6} strokeLinecap="round" opacity={0.6} />
      </svg>
    </Abs>
  );
}

// ------------------------------------------------------------ HP & WA ------
const MSGS = [
  'Ayo kumpul!', 'Hello from Brazil', 'Arisan kapan?', 'Udah makan?', 'Konnichiwa, apa kabar?',
  'Kirim fotonya dong', 'Selamat pagi semua', 'Siapa ini?', 'Share dulu', 'Salam dari Mesir',
  'Hati-hati di jalan', 'Bonjour keluarga!', 'Jangan lupa doa', 'Ini hoaks bukan?',
];

export function WaLogo({cx, cy, r}: {cx: number; cy: number; r: number}) {
  return (
    <g>
      <circle cx={cx} cy={cy} r={r} fill="#25D366" stroke={INK} strokeWidth={r * 0.1} />
      <path d={`M${cx - r * 0.5},${cy + r * 0.62} L${cx - r * 0.36},${cy + r * 0.28} A${r * 0.52},${r * 0.52} 0 1 1 ${cx - r * 0.1},${cy + r * 0.52} Z`} fill="#fff" />
      <path d={`M${cx - r * 0.18},${cy - r * 0.2} Q${cx - r * 0.1},${cy + r * 0.25} ${cx + r * 0.25},${cy + r * 0.2}`} fill="none" stroke="#25D366" strokeWidth={r * 0.16} strokeLinecap="round" />
    </g>
  );
}

export function ChatBubble({x, y, text, out, s = 1}: {x: number; y: number; text: string; out: boolean; s?: number}) {
  const w = 40 + text.length * 15;
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      <rect x={0} y={0} width={w} height={52} rx={16} fill={out ? '#DCF8C6' : '#fff'} stroke={INK} strokeWidth={4} />
      <text x={16} y={34} fontSize={24} fontWeight={700} fontFamily="Arial, sans-serif" fill={INK}>{text}</text>
    </g>
  );
}

export function PhoneBig({box, f, count, bubbles = 0}: {box: Box; f: number; count: number; bubbles?: number}) {
  const items: ReactNode[] = [];
  const n = Math.min(MSGS.length, Math.floor(bubbles));
  for (let i = 0; i < n; i++) {
    const y = 760 - (n - 1 - i) * 74 + (bubbles - n) * 74;
    items.push(<ChatBubble key={i} x={i % 2 ? 380 : 40} y={y} text={MSGS[i]} out={i % 2 === 1} />);
  }
  return (
    <Abs box={box}>
      <svg width="100%" height="100%" viewBox="0 0 800 1040" style={{overflow: 'visible'}}>
        <rect x={0} y={0} width={800} height={1040} rx={70} fill="#222" stroke={INK} strokeWidth={10} />
        <rect x={26} y={26} width={748} height={988} rx={48} fill="#ECE5DD" />
        <clipPath id="ph-s"><rect x={26} y={26} width={748} height={988} rx={48} /></clipPath>
        <g clipPath="url(#ph-s)">
          <rect x={26} y={26} width={748} height={170} fill="#075E54" />
          <circle cx={110} cy={118} r={50} fill="#fff" stroke={INK} strokeWidth={5} />
          <path d="M84,126 Q110,168 136,126 M92,98 Q110,76 128,98" fill="none" stroke={INK} strokeWidth={5} strokeLinecap="round" />
          <text x={190} y={106} fontSize={46} fontWeight={900} fontFamily="Arial, sans-serif" fill="#fff">Keluarga Indonesia</text>
          <text x={190} y={158} fontSize={32} fontWeight={700} fontFamily="Arial, sans-serif" fill="#C8F0E0">{fmtDots(count)} anggota</text>
          {Array.from({length: 22}).map((_, i) => (
            <circle key={i} cx={60 + (i % 6) * 130} cy={260 + Math.floor(i / 6) * 150} r={5} fill="#D4CABA" />
          ))}
          <g transform="translate(0 40)">{items}</g>
          <rect x={26} y={934} width={748} height={80} fill="#F0F0F0" />
          <rect x={50} y={946} width={600} height={56} rx={28} fill="#fff" stroke={INK} strokeWidth={3} />
          <circle cx={712} cy={974} r={32} fill="#25D366" stroke={INK} strokeWidth={4} />
        </g>
        <rect x={300} y={6} width={200} height={26} rx={13} fill={INK} />
        <rect x={0} y={0} width={0} height={0} opacity={f} />
      </svg>
    </Abs>
  );
}

export function PhoneSmall({box, f}: {box: Box; f: number}) {
  const glow = 0.5 + wob(f, 40, 0.15);
  return (
    <Abs box={box} style={{transform: 'rotate(-8deg)'}}>
      <svg width="100%" height="100%" viewBox="0 0 260 420" style={{overflow: 'visible'}}>
        <circle cx={130} cy={210} r={230} fill="#25D366" opacity={0.16 * glow} />
        <rect x={0} y={0} width={260} height={420} rx={34} fill="#222" stroke={INK} strokeWidth={7} />
        <rect x={14} y={14} width={232} height={392} rx={24} fill="#DFF7E4" />
        <WaLogo cx={130} cy={170} r={64} />
        <rect x={50} y={270} width={160} height={22} rx={10} fill="#fff" stroke={INK} strokeWidth={3} />
        <rect x={50} y={310} width={110} height={22} rx={10} fill="#fff" stroke={INK} strokeWidth={3} />
        <rect x={94} y={6} width={72} height={12} rx={6} fill={INK} />
      </svg>
    </Abs>
  );
}

/** Lautan gelembung chat yang memenuhi kotak (masing-masing muncul bertahap). */
export function BubbleField({box, t, seed = 21, count = 70, appearFrames = 40}: {
  box: Box; t: number; seed?: number; count?: number; appearFrames?: number;
}) {
  const r = rng(seed);
  const items: ReactNode[] = [];
  for (let i = 0; i < count; i++) {
    const x = r() * (box.w - 120) - 40;
    const y = r() * (box.h - 40);
    const s = 0.7 + r() * 0.9;
    const born = (i / count) * appearFrames;
    const k = clamp((t - born) / 5);
    if (k <= 0) continue;
    items.push(
      <g key={i} transform={`translate(${wob(t + i * 3, 30, 4)} ${wob(t + i * 5, 26, 4)})`}>
        <g transform={`translate(${x} ${y}) scale(${k}) translate(${-x} ${-y})`}>
          <ChatBubble x={x} y={y} text={MSGS[i % MSGS.length]} out={i % 3 === 0} s={s} />
        </g>
      </g>,
    );
    if (i % 7 === 0) {
      items.push(
        <g key={`b${i}`} transform={`translate(${x + 60} ${y - 10}) scale(${k})`}>
          <circle r={20} fill={RED} stroke={INK} strokeWidth={4} />
          <text y={8} textAnchor="middle" fontSize={22} fontWeight={900} fontFamily="Arial, sans-serif" fill="#fff">{(i % 9) + 1}</text>
        </g>,
      );
    }
  }
  return (
    <Abs box={box}>
      <svg width="100%" height="100%" viewBox={`0 0 ${box.w} ${box.h}`} style={{overflow: 'hidden'}}>{items}</svg>
    </Abs>
  );
}

// ----------------------------------------------------------- Skyline -------
export function Skyline({box, f, dark = true}: {box: Box; f: number; dark?: boolean}) {
  const c = dark ? '#2A2E36' : '#555';
  const wave = Array.from({length: 9}, (_, i) => `${i * 14},${Math.sin((f + i * 6) / 7) * 4}`).join(' ');
  return (
    <Abs box={box}>
      <svg width="100%" height="100%" viewBox={`0 0 ${box.w} ${box.h}`} style={{overflow: 'hidden'}}>
        {[[0, 300, 120], [130, 360, 90], [230, 260, 110], [760, 330, 100], [870, 280, 120], [1000, 350, 100]].map(([x, h, w], i) => (
          <rect key={i} x={x} y={box.h - h} width={w} height={h} fill={c} stroke={INK} strokeWidth={5} />
        ))}
        {/* Monas */}
        <g transform={`translate(880 ${box.h})`}>
          <rect x={-90} y={-70} width={180} height={70} fill="#3A3F49" stroke={INK} strokeWidth={5} />
          <polygon points="-18,-70 18,-70 8,-420 -8,-420" fill="#CFCFCF" stroke={INK} strokeWidth={5} strokeLinejoin="round" />
          <rect x={-34} y={-440} width={68} height={24} fill="#BDBDBD" stroke={INK} strokeWidth={5} />
          <path d="M0,-520 Q22,-470 0,-440 Q-22,-470 0,-520 Z" fill="#FFC928" stroke={INK} strokeWidth={5} />
        </g>
        {/* tiang bendera */}
        <line x1={150} y1={box.h} x2={150} y2={box.h - 700} stroke={INK} strokeWidth={9} />
        <g transform={`translate(156 ${box.h - 700})`}>
          <polygon points={wave + ' 112,84 0,84'} fill="#fff" stroke={INK} strokeWidth={5} />
          <polygon points={wave + ' 112,42 0,42'} fill={RED} stroke={INK} strokeWidth={5} />
        </g>
        <Star4 x={470} y={120} r={10} />
        <Star4 x={640} y={70} r={8} />
      </svg>
    </Abs>
  );
}
