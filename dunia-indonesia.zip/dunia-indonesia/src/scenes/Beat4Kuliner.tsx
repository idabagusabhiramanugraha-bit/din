import {AbsoluteFill} from 'remotion';
import {SceneSeq, useScene} from '../lib/scene';
import {Camera} from '../lib/Camera';
import {easeOutCubic, pop, prog, rng, wob} from '../lib/anim';
import {SCENE_LAYOUT} from '../data/layout';
import {Stickman, POSES, blendPose} from '../components/Stickman';
import {Label} from '../components/Label';
import {Abs, Burst, Earth, Star4, INK, RED} from '../components/art1';
import {Bunting, Chili, FoodTable} from '../components/art2';

const L = SCENE_LAYOUT;
const FULL = {x: 0, y: 0, w: 1080, h: 1500};

// S12: meja makanan Indonesia, kamera mendekat ke piring.
function S12() {
  const {t, dur, fps} = useScene();
  return (
    <AbsoluteFill style={{background: '#F4D58D'}}>
      <Bunting box={L.S12.objs.bunting} f={t} />
      <Camera t={t} dur={dur} s={[1.0, 1.25]} origin={[540, 1050]}>
        <FoodTable box={L.S12.objs.table} f={t} />
      </Camera>
      <Label text="KULINER INDONESIA" t={t} fps={fps} delay={4} />
    </AbsoluteFill>
  );
}

// S13: karakter menyantap makanan dengan ekspresi sangat bahagia.
function S13() {
  const {t, dur, fps} = useScene();
  const enter = pop(t, fps, 0, 12, 140);
  const chew = wob(t, 12, 22);
  const pl = L.S13.objs.plate;
  const r = rng(13);
  const bits = Array.from({length: 8}, (_, i) => ({a: r() * 6.28, rad: 260 + r() * 120, c: ['#D9A441', '#7A3E1A', RED, '#FFD54F'][i % 4], sz: 14 + r() * 12}));
  return (
    <AbsoluteFill style={{background: '#FFCE7A'}}>
      <Burst box={FULL} f={t} a="#FFE0A0" b="#FFB74D" />
      <Camera t={t} dur={dur} x={[40, -40]} s={[1.05, 1.1]} origin={[400, 1000]}>
        <Stickman
          box={L.S13.char!}
          expr="joy"
          pose={{...blendPose(POSES.stand, POSES.eat, enter), aR: [100, 150 + chew]}}
          f={t}
          fx={['sparkle']}
          rot={wob(t, 24, 2)}
        />
        <Abs box={pl}>
          <svg width="100%" height="100%" viewBox="0 0 340 400" style={{overflow: 'visible'}}>
            <ellipse cx={170} cy={300} rx={160} ry={64} fill="#fff" stroke={INK} strokeWidth={7} />
            <path d="M40,296 Q70,190 170,188 Q270,190 300,296 Q170,340 40,296 Z" fill="#D9A441" stroke={INK} strokeWidth={6} />
            <ellipse cx={176} cy={208} rx={44} ry={20} fill="#fff" stroke={INK} strokeWidth={5} />
            <circle cx={176} cy={207} r={11} fill="#FFC107" stroke={INK} strokeWidth={4} />
          </svg>
        </Abs>
        <svg width={1080} height={1500} style={{position: 'absolute', left: 0, top: 0, overflow: 'visible'}}>
          {bits.map((b, i) => {
            const a = b.a + t * 0.05;
            return <circle key={i} cx={380 + Math.cos(a) * b.rad} cy={900 + Math.sin(a) * b.rad * 0.55} r={b.sz} fill={b.c} stroke={INK} strokeWidth={4} />;
          })}
          <Star4 x={140} y={640 + wob(t, 20, 8)} r={30} />
        </svg>
      </Camera>
    </AbsoluteFill>
  );
}

// S14: karakter mengangkat cabai bak harta karun, koin berjatuhan.
function S14() {
  const {t, dur, fps} = useScene();
  const enter = pop(t, fps, 0, 12, 130);
  const r = rng(14);
  const coins = Array.from({length: 16}, (_, i) => ({x: 60 + r() * 960, d: i * 5, v: 520 + r() * 260, s: 18 + r() * 14}));
  return (
    <AbsoluteFill style={{background: '#FFB3A7'}}>
      <Burst box={FULL} f={t} a="#FFC9BE" b="#FF9E8F" n={18} />
      <Camera t={t} dur={dur} y={[-90, 0]} s={[1.15, 1.0]} origin={[540, 1000]} ease={easeOutCubic}>
        <svg width={1080} height={1500} style={{position: 'absolute', left: 0, top: 0}}>
          <circle cx={650} cy={900} r={330} fill="#FFD400" opacity={0.3 * enter} />
        </svg>
        <Stickman box={L.S14.char!} expr="smug" pose={blendPose(POSES.stand, POSES.chili, enter)} f={t} fx={['sparkle']} />
        <Chili box={L.S14.objs.chili} f={t} angle={-8} />
        <svg width={1080} height={1500} style={{position: 'absolute', left: 0, top: 0, overflow: 'hidden'}}>
          {coins.map((c, i) => {
            const k = Math.max(0, (t - c.d) / fps);
            if (t < c.d) return null;
            const y = -40 + c.v * k;
            if (y > 1540) return null;
            return (
              <g key={i}>
                <circle cx={c.x + wob(t + i * 5, 30, 14)} cy={y} r={c.s} fill="#FFC928" stroke={INK} strokeWidth={4} />
                <circle cx={c.x + wob(t + i * 5, 30, 14)} cy={y} r={c.s * 0.55} fill="none" stroke="#C9A227" strokeWidth={3} />
              </g>
            );
          })}
        </svg>
      </Camera>
    </AbsoluteFill>
  );
}

// S15: bumi dikelilingi cabai yang mengorbit; kamera dramatis.
function S15() {
  const {t, dur, fps} = useScene();
  const e = L.S15.objs.earth;
  const cx = e.x + e.w / 2;
  const cy = e.y + e.h / 2;
  const N = 9;
  const items = Array.from({length: N}, (_, i) => {
    const a = (i / N) * Math.PI * 2 + t * 0.045;
    return {i, x: cx + Math.cos(a) * 470, y: cy + Math.sin(a) * 150, front: Math.sin(a) > 0, deg: (Math.cos(a) * 180) / Math.PI * 0.4 + (Math.sin(a) > 0 ? 90 : -90)};
  });
  const render = (front: boolean) =>
    items.filter((o) => o.front === front).map((o) => (
      <Chili key={o.i} box={{x: o.x - 60, y: o.y - 120, w: 120, h: 240}} f={t + o.i * 5} angle={o.deg} />
    ));
  return (
    <AbsoluteFill style={{background: '#FF8A65'}}>
      <Burst box={FULL} f={t} a="#FFAB91" b="#FF7043" n={26} speed={0.006} />
      <Camera t={t} dur={dur} s={[0.85, 1.3]} r={[-5, 5]} origin={[cx, cy]}>
        {render(false)}
        <Earth box={e} f={t} flag={1} wave={t} id="s15" />
        {render(true)}
      </Camera>
      <Label text="KOMODITAS PALING BERHARGA" t={t} fps={fps} delay={6} />
    </AbsoluteFill>
  );
}

export const Beat4Kuliner = ({beatFrom}: {beatFrom: number}) => (
  <>
    <SceneSeq id="S12" beatFrom={beatFrom}><S12 /></SceneSeq>
    <SceneSeq id="S13" beatFrom={beatFrom}><S13 /></SceneSeq>
    <SceneSeq id="S14" beatFrom={beatFrom}><S14 /></SceneSeq>
    <SceneSeq id="S15" beatFrom={beatFrom}><S15 /></SceneSeq>
  </>
);

// prog dipakai oleh beat lain; diekspor ulang agar impor ringkas tidak dianggap tak terpakai.
export {prog};
