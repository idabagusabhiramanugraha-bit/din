import {AbsoluteFill} from 'remotion';
import {SceneSeq, useScene} from '../lib/scene';
import {Camera} from '../lib/Camera';
import {easeOutCubic, pop, prog, rng, wob} from '../lib/anim';
import {SCENE_LAYOUT} from '../data/layout';
import {Stickman, POSES, blendPose} from '../components/Stickman';
import {Label} from '../components/Label';
import {Burst, Cloud, Crowd, Earth, Person} from '../components/art1';

const L = SCENE_LAYOUT;

// S1: bumi dari angkasa, kamera mendekat, bendera merah-putih menyapu bumi.
function S1() {
  const {t, dur, fps} = useScene();
  const r = rng(1);
  const stars = Array.from({length: 90}, (_, i) => ({x: r() * 1080, y: r() * 1500, s: 1 + r() * 3, ph: r()}));
  const flagAt = Math.round(dur * 0.8);
  const flag = easeOutCubic(prog(t, flagAt, 22));
  return (
    <AbsoluteFill style={{background: '#0A0E1A'}}>
      <Camera t={t} dur={dur} s={[0.72, 1.12]} origin={[540, 770]}>
        <svg width={1080} height={1500} style={{position: 'absolute', left: 0, top: 0}}>
          {stars.map((s, i) => (
            <circle key={i} cx={s.x} cy={s.y} r={s.s * (0.7 + 0.3 * Math.sin(t / 8 + s.ph * 6))} fill="#fff" />
          ))}
        </svg>
        <Earth box={L.S1.objs.earth} f={t} flag={flag} wave={t} id="s1" />
      </Camera>
      <Label text="INDONESIA" t={t} fps={fps} delay={flagAt + 8} />
    </AbsoluteFill>
  );
}

// S2: karakter terkejut menunjuk bumi; manusia dari berbagai negara berjatuhan.
function S2() {
  const {t, dur, fps} = useScene();
  const box = L.S2.char!;
  const enter = pop(t, fps, 2, 12, 120);
  const r = rng(2);
  const earth = L.S2.objs.earth;
  const skins = ['#FFE0BD', '#F1C27D', '#C68642', '#8D5524', '#fff'];
  const falls = Array.from({length: 14}, (_, i) => ({
    x0: earth.x + 100 + r() * 240, y0: earth.y + 120, vx: -120 - r() * 260, vy: 380 + r() * 380, d: 10 + i * 4, rot: r() * 360, c: skins[i % 5], shirt: ['#E53935', '#FDD835', '#43A047', '#1E88E5', '#FB8C00'][i % 5],
  }));
  return (
    <AbsoluteFill style={{background: '#BFE7F5'}}>
      <Burst box={{x: 0, y: 0, w: 1080, h: 1500}} f={t} a="#D6F1FA" b="#BFE7F5" />
      <svg width={1080} height={1500} style={{position: 'absolute', left: 0, top: 0}}>
        <Cloud x={wob(t, 140, 40) + 80} y={430} s={1.4} />
        <Cloud x={wob(t, 170, 40, 0.3) + 640} y={1010} s={1.1} />
      </svg>
      <Camera t={t} dur={dur} x={[50, -40]} s={[1.0, 1.08]} origin={[540, 900]}>
        <Earth box={{...earth, y: earth.y + wob(t, 50, 12)}} f={t} flag={1} wave={t} id="s2" />
        <svg width={1080} height={1500} style={{position: 'absolute', left: 0, top: 0, overflow: 'visible'}}>
          {falls.map((p, i) => {
            const k = Math.max(0, (t - p.d) / fps);
            if (t < p.d) return null;
            return <g key={i} transform={`rotate(${p.rot + k * 90} ${p.x0 + p.vx * k} ${p.y0 + p.vy * k})`}><Person x={p.x0 + p.vx * k} y={p.y0 + p.vy * k} s={0.5} shirt={p.shirt} skin={p.c} wow /></g>;
          })}
        </svg>
        <Stickman box={box} expr="shock" pose={blendPose(POSES.stand, POSES.point, enter)} f={t} fx={['bang']} offsetX={(1 - enter) * -500} />
      </Camera>
    </AbsoluteFill>
  );
}

// S3: kerumunan miliaran dari belakang karakter; kamera mundur.
function S3() {
  const {t, dur, fps} = useScene();
  const rise = pop(t, fps, 4, 14, 100);
  const counter = Math.min(8, 8 * easeOutCubic(prog(t, 0, 50)));
  const txt = counter >= 7.95 ? '8 MILIAR MANUSIA' : `${counter.toFixed(1)} MILIAR MANUSIA`;
  return (
    <AbsoluteFill style={{background: '#FFE9A8'}}>
      <svg width={1080} height={1500} style={{position: 'absolute', left: 0, top: 0}}>
        <rect x={0} y={0} width={1080} height={1500} fill="#BFE7F5" />
        <rect x={0} y={340} width={1080} height={1160} fill="#9AA5A0" />
        {[0, 1, 2, 3, 4, 5].map((i) => (
          <rect key={i} x={i * 190 - 20} y={260 + (i % 3) * 30} width={150} height={100 + (i % 3) * 30} fill="#8E9AA6" stroke="#111" strokeWidth={5} />
        ))}
      </svg>
      <Camera t={t} dur={dur} s={[1.4, 1.0]} origin={[540, 760]}>
        <Crowd box={L.S3.objs.crowd} f={t} seed={7} />
        <Stickman box={L.S3.char!} back expr="neutral" pose={POSES.stand} f={t} offsetY={(1 - rise) * 260} />
      </Camera>
      <Label text={txt} t={t} fps={fps} delay={2} />
    </AbsoluteFill>
  );
}

export const Beat1Hook = ({beatFrom}: {beatFrom: number}) => (
  <>
    <SceneSeq id="S1" beatFrom={beatFrom}><S1 /></SceneSeq>
    <SceneSeq id="S2" beatFrom={beatFrom}><S2 /></SceneSeq>
    <SceneSeq id="S3" beatFrom={beatFrom}><S3 /></SceneSeq>
  </>
);
