import {AbsoluteFill} from 'remotion';
import {SceneSeq, useScene} from '../lib/scene';
import {Camera} from '../lib/Camera';
import {pop, rng, wob} from '../lib/anim';
import {SCENE_LAYOUT} from '../data/layout';
import {Stickman, POSES, blendPose} from '../components/Stickman';
import {Abs, Earth, Star4} from '../components/art1';
import {Skyline} from '../components/art2';

const L = SCENE_LAYOUT;

// S20: karakter berpikir, bumi berbendera di latar; langit senja.
function S20() {
  const {t, dur, fps} = useScene();
  const enter = pop(t, fps, 0, 14, 110);
  const r = rng(20);
  const stars = Array.from({length: 22}, () => ({x: r() * 1080, y: 80 + r() * 700, s: 4 + r() * 8}));
  return (
    <AbsoluteFill style={{background: 'linear-gradient(180deg,#1F2A36 0%,#35505C 55%,#E8743B 100%)'}}>
      <svg width={1080} height={1500} style={{position: 'absolute', left: 0, top: 0}}>
        {stars.map((s, i) => (
          <circle key={i} cx={s.x} cy={s.y} r={s.s * (0.6 + 0.4 * Math.sin(t / 9 + i))} fill="#FFF3C4" />
        ))}
        <rect x={0} y={1400} width={1080} height={100} fill="#161B22" />
      </svg>
      <Camera t={t} dur={dur} x={[24, -24]} s={[1.0, 1.05]} origin={[540, 950]}>
        <Earth box={{...L.S20.objs.earth, y: L.S20.objs.earth.y + wob(t, 60, 10)}} f={t} flag={1} wave={t} id="s20" />
        <Stickman box={L.S20.char!} expr="think" pose={blendPose(POSES.stand, POSES.think, enter)} f={t} fx={['question']} />
      </Camera>
    </AbsoluteFill>
  );
}

// S21: karakter menoleh ke kamera, pertanyaan besar muncul, lalu tahan agar penonton sempat berpikir.
function S21() {
  const {t, dur, fps} = useScene();
  const enter = pop(t, fps, 0, 14, 120);
  const title = pop(t, fps, 22, 9, 200);
  const tb = L.S21.objs.title;
  return (
    <AbsoluteFill style={{background: 'linear-gradient(180deg,#1F2A36 0%,#3E5B66 50%,#F0883E 100%)'}}>
      <Camera t={t} dur={dur} s={[1.1, 1.0]} origin={[540, 1000]}>
        <Skyline box={{x: 0, y: 560, w: 1080, h: 940}} f={t} />
        <Stickman box={L.S21.char!} flip={t < 8} expr="smug" pose={blendPose(POSES.think, POSES.hips, enter)} f={t} scale={0.9 + 0.1 * enter} fx={['sparkle']} />
      </Camera>
      {t >= 22 ? (
        <Abs box={tb} style={{display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
          <div
            style={{
              transform: `scale(${0.3 + 0.7 * title}) rotate(${(1 - title) * -10 - 3}deg)`,
              fontFamily: '"Arial Black", Impact, Arial, sans-serif',
              fontWeight: 900,
              fontSize: 86,
              color: '#FFD400',
              WebkitTextStroke: '12px #111',
              paintOrder: 'stroke fill',
              whiteSpace: 'nowrap',
              letterSpacing: 2,
            }}
          >
            MENURUT KAMU?
          </div>
        </Abs>
      ) : null}
      <svg width={1080} height={1500} style={{position: 'absolute', left: 0, top: 0}}>
        <Star4 x={120} y={360 + wob(t, 30, 8)} r={20} />
        <Star4 x={960} y={300} r={16} />
      </svg>
    </AbsoluteFill>
  );
}

export const Beat6Ending = ({beatFrom}: {beatFrom: number}) => (
  <>
    <SceneSeq id="S20" beatFrom={beatFrom}><S20 /></SceneSeq>
    <SceneSeq id="S21" beatFrom={beatFrom}><S21 /></SceneSeq>
  </>
);
