import {AbsoluteFill} from 'remotion';
import {SceneSeq, useScene} from '../lib/scene';
import {Camera} from '../lib/Camera';
import {easeOutCubic, pop, prog, wob} from '../lib/anim';
import {SCENE_LAYOUT} from '../data/layout';
import {Stickman, POSES, blendPose} from '../components/Stickman';
import {Label} from '../components/Label';
import {BubbleField, PhoneBig, PhoneSmall} from '../components/art2';

const L = SCENE_LAYOUT;

// S16: karakter memegang HP; ekspresi datar lalu terkejut.
function S16() {
  const {t, dur, fps} = useScene();
  const k = prog(t, 0, dur);
  const enter = pop(t, fps, 0, 14, 110);
  const startled = k > 0.55;
  return (
    <AbsoluteFill style={{background: '#1B1F24'}}>
      <svg width={1080} height={1500} style={{position: 'absolute', left: 0, top: 0}}>
        <circle cx={700} cy={1000} r={620} fill="#25D366" opacity={0.1} />
        <rect x={0} y={1320} width={1080} height={180} fill="#12151A" />
      </svg>
      <Camera t={t} dur={dur} s={[1.0, 1.25]} origin={[480, 900]}>
        <Stickman
          box={L.S16.char!}
          expr={startled ? 'shock' : 'neutral'}
          pose={blendPose(POSES.stand, POSES.hold, enter)}
          f={t}
          fx={startled ? ['bang'] : []}
          shake={startled ? 3 : 0}
        />
        <PhoneSmall box={L.S16.objs.phone} f={t} />
      </Camera>
    </AbsoluteFill>
  );
}

// S17: layar grup "Keluarga Indonesia", jumlah anggota menanjak ke 8 miliar.
function S17() {
  const {t, dur} = useScene();
  const count = 8000000000 * easeOutCubic(prog(t, 4, Math.max(30, dur * 0.7)));
  return (
    <AbsoluteFill style={{background: '#1B1F24'}}>
      <Camera t={t} dur={dur} s={[0.94, 1.1]} origin={[540, 900]}>
        <PhoneBig box={L.S17.objs.phone} f={t} count={Math.max(1, count)} bubbles={Math.min(4, t / 12)} />
      </Camera>
    </AbsoluteFill>
  );
}

// S18: notifikasi dan pesan terus berdatangan.
function S18() {
  const {t, dur, fps} = useScene();
  return (
    <AbsoluteFill style={{background: '#1B1F24'}}>
      <Camera t={t} dur={dur} s={[1.1, 1.0]} origin={[540, 900]}>
        <PhoneBig box={L.S18.objs.phone} f={t} count={8000000000} bubbles={Math.min(9, 3 + t / 5)} />
        <div style={{position: 'absolute', left: wob(t, 3, 4), top: wob(t, 4, 4), width: 1080, height: 1500}} />
      </Camera>
      <Label text="99+ PESAN BARU" t={t} fps={fps} delay={4} color="#fff" />
    </AbsoluteFill>
  );
}

// S19: gelembung memenuhi layar; karakter panik, kamera mundur cepat.
function S19() {
  const {t, dur} = useScene();
  const flash = t > dur - 4 ? 0.9 : 0;
  return (
    <AbsoluteFill style={{background: '#ECE5DD'}}>
      <Camera t={t} dur={dur} s={[2.0, 0.85]} origin={[540, 1130]} ease={easeOutCubic}>
        <BubbleField box={L.S19.objs.bubbles} t={t} seed={21} count={80} appearFrames={Math.max(20, dur * 0.7)} />
        <Stickman box={L.S19.char!} expr="panic" pose={POSES.panic} f={t} fx={['sweat']} shake={4} />
      </Camera>
      {flash > 0 ? <div style={{position: 'absolute', inset: 0, background: '#fff', opacity: flash}} /> : null}
    </AbsoluteFill>
  );
}

export const Beat5WhatsApp = ({beatFrom}: {beatFrom: number}) => (
  <>
    <SceneSeq id="S16" beatFrom={beatFrom}><S16 /></SceneSeq>
    <SceneSeq id="S17" beatFrom={beatFrom}><S17 /></SceneSeq>
    <SceneSeq id="S18" beatFrom={beatFrom}><S18 /></SceneSeq>
    <SceneSeq id="S19" beatFrom={beatFrom}><S19 /></SceneSeq>
  </>
);
