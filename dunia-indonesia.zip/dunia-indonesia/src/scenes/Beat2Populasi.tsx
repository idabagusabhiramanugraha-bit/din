import {AbsoluteFill} from 'remotion';
import {SceneSeq, useScene} from '../lib/scene';
import {Camera} from '../lib/Camera';
import {easeOutCubic, pop, prog, wob} from '../lib/anim';
import {SCENE_LAYOUT} from '../data/layout';
import {Stickman, POSES, blendPose} from '../components/Stickman';
import {Label} from '../components/Label';
import {Burst, Star4} from '../components/art1';
import {KtpCard, Scale, WorldMap} from '../components/art2';

const L = SCENE_LAYOUT;

// S4: karakter bangga memegang KTP; kamera mendekat ke KTP.
function S4() {
  const {t, dur, fps} = useScene();
  const enter = pop(t, fps, 2, 12, 140);
  const ktp = L.S4.objs.ktp;
  return (
    <AbsoluteFill style={{background: '#FFE9A8'}}>
      <Burst box={{x: 0, y: 0, w: 1080, h: 1500}} f={t} a="#FFF3C4" b="#FFD36B" />
      <Camera t={t} dur={dur} s={[1.0, 1.35]} origin={[760, 880]}>
        <Stickman box={L.S4.char!} expr="smug" pose={blendPose(POSES.stand, POSES.hold, enter)} f={t} scale={0.85 + 0.15 * enter} />
        <div style={{position: 'absolute', left: 0, top: 0, transform: `scale(${enter}) rotate(${-6 + wob(t, 50, 2)}deg)`, transformOrigin: `${ktp.x + 170}px ${ktp.y + 110}px`, width: 1080, height: 1500}}>
          <KtpCard box={ktp} f={t} />
        </div>
        <svg width={1080} height={1500} style={{position: 'absolute', left: 0, top: 0, overflow: 'visible'}}>
          <Star4 x={ktp.x - 30 + wob(t, 24, 6)} y={ktp.y - 10} r={26} />
          <Star4 x={ktp.x + ktp.w + 30} y={ktp.y + 40 + wob(t, 20, 6)} r={20} />
        </svg>
      </Camera>
      <Label text="KTP" t={t} fps={fps} delay={6} />
    </AbsoluteFill>
  );
}

// S5: peta dunia; Indonesia membesar jadi pusat perhatian, negara lain bergetar cemas.
function S5() {
  const {t, dur, fps} = useScene();
  const grow = pop(t, fps, 8, 10, 120);
  return (
    <AbsoluteFill style={{background: '#9ADBF5'}}>
      <Camera t={t} dur={dur} s={[1.0, 1.25]} x={[0, -70]} origin={[850, 810]}>
        <WorldMap box={L.S5.objs.map} f={t} grow={grow} />
      </Camera>
      <Stickman box={L.S5.char!} expr="awe" pose={POSES.wow} f={t} scale={0.9} />
      <Label text="PENDUDUK TERBANYAK" t={t} fps={fps} delay={12} />
    </AbsoluteFill>
  );
}

// S6: skala populasi — Indonesia lebih berat daripada gabungan benua.
function S6() {
  const {t, dur, fps} = useScene();
  const k = easeOutCubic(prog(t, 6, 40));
  const tilt = 15 * k + wob(t, 24, 1.2) * k;
  const enter = pop(t, fps, 4, 12, 130);
  return (
    <AbsoluteFill style={{background: '#D5F5E3'}}>
      <Burst box={{x: 0, y: 0, w: 1080, h: 1500}} f={t} a="#E6FAEF" b="#C5EFD6" n={22} />
      <Camera t={t} dur={dur} s={[1.25, 1.0]} origin={[760, 850]}>
        <Scale box={L.S6.objs.scale} tilt={tilt} f={t} />
        <Stickman box={L.S6.char!} expr="awe" pose={blendPose(POSES.stand, POSES.wow, enter)} f={t} />
      </Camera>
    </AbsoluteFill>
  );
}

export const Beat2Populasi = ({beatFrom}: {beatFrom: number}) => (
  <>
    <SceneSeq id="S4" beatFrom={beatFrom}><S4 /></SceneSeq>
    <SceneSeq id="S5" beatFrom={beatFrom}><S5 /></SceneSeq>
    <SceneSeq id="S6" beatFrom={beatFrom}><S6 /></SceneSeq>
  </>
);
