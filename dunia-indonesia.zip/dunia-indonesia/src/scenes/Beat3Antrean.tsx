import {AbsoluteFill} from 'remotion';
import {SceneSeq, useScene} from '../lib/scene';
import {Camera} from '../lib/Camera';
import {easeOutCubic, pop, prog, wob} from '../lib/anim';
import {SCENE_LAYOUT} from '../data/layout';
import {Stickman, POSES, blendPose} from '../components/Stickman';
import {Label} from '../components/Label';
import {Abs, Burst, Person, SpeedLines, Star4, Queue} from '../components/art1';
import {Clock, Dukcapil, Ticket} from '../components/art2';

const L = SCENE_LAYOUT;
const FULL = {x: 0, y: 0, w: 1080, h: 1500};

// S7: kantor DUKCAPIL, antrean sangat panjang; dolly maju menyusuri antrean.
function S7() {
  const {t, dur, fps} = useScene();
  return (
    <AbsoluteFill style={{background: '#BFE7F5'}}>
      <svg width={1080} height={1500} style={{position: 'absolute', left: 0, top: 0}}>
        <rect x={0} y={900} width={1080} height={600} fill="#9AA5A0" />
      </svg>
      <Camera t={t} dur={dur} s={[1.0, 1.15]} origin={[540, 980]}>
        <Dukcapil box={L.S7.objs.building} f={t} />
      </Camera>
      <Camera t={t} dur={dur} s={[1.0, 1.7]} origin={[540, 980]}>
        <Queue box={L.S7.objs.queue} f={t} vp={[540, 980]} />
      </Camera>
      <Label text="DUKCAPIL" t={t} fps={fps} delay={4} />
    </AbsoluteFill>
  );
}

// S8: karakter lelah di tengah antrean; jam berputar cepat.
function S8() {
  const {t, dur, fps} = useScene();
  const q = L.S8.objs.queue;
  return (
    <AbsoluteFill style={{background: '#D9D9D9'}}>
      <svg width={1080} height={1500} style={{position: 'absolute', left: 0, top: 0}}>
        <rect x={0} y={0} width={1080} height={380} fill="#BFE7F5" />
        <rect x={0} y={380} width={1080} height={1120} fill="#B5B5B5" />
      </svg>
      <Camera t={t} dur={dur} s={[1.0, 1.25]} x={[0, -30]} origin={[540, 900]}>
        <Queue box={q} f={t} vp={[540, 560]} seed={9} count={40} />
      </Camera>
      <Stickman box={L.S8.char!} expr="tired" pose={blendPose(POSES.stand, POSES.slump, easeOutCubic(prog(t, 0, 40)))} f={t} fx={['swirl', 'sweat']} />
      <Clock box={L.S8.objs.clock} t={t} />
      <Label text="KTP · SIM" t={t} fps={fps} delay={4} />
    </AbsoluteFill>
  );
}

// S9: karakter duduk lemas memegang nomor antrean; kamera low-angle bergoyang.
function S9() {
  const {t, dur, fps} = useScene();
  const enter = pop(t, fps, 0, 14, 90);
  const expr = prog(t, 0, dur) > 0.55 ? 'confused' : 'tired';
  return (
    <AbsoluteFill style={{background: '#E8DCC8'}}>
      <svg width={1080} height={1500} style={{position: 'absolute', left: 0, top: 0}}>
        <rect x={0} y={1000} width={1080} height={500} fill="#B9B2A4" />
        <line x1={0} y1={1000} x2={1080} y2={1000} stroke="#111" strokeWidth={6} />
        {[0, 1, 2, 3].map((i) => (
          <rect key={i} x={80 + i * 260} y={420} width={180} height={300} fill="#CBE6F2" stroke="#111" strokeWidth={6} />
        ))}
      </svg>
      <Camera t={t} dur={dur} r={[-1.2, 1.2]} s={[1.05, 1.0]} origin={[540, 1100]}>
        <Stickman box={L.S9.char!} vb="-60 220 520 480" expr={expr} pose={POSES.sit} f={t} fx={['swirl']} offsetY={(1 - enter) * 160} />
        <Ticket box={L.S9.objs.ticket} f={t} />
      </Camera>
    </AbsoluteFill>
  );
}

// S10: seseorang menyapa; karakter kaget lalu berdiri tegak.
function S10() {
  const {t, dur, fps} = useScene();
  const k = prog(t, 0, dur);
  const a = L.S10.objs.asker;
  const s = 4;
  return (
    <AbsoluteFill style={{background: '#E3D9C3'}}>
      <svg width={1080} height={1500} style={{position: 'absolute', left: 0, top: 0}}>
        <rect x={0} y={1180} width={1080} height={320} fill="#A8A092" />
        <line x1={0} y1={1180} x2={1080} y2={1180} stroke="#111" strokeWidth={6} />
      </svg>
      <Camera t={t} dur={dur} s={[1.0, 1.25]} ease={easeOutCubic} origin={[560, 1000]}>
        <Abs box={a}>
          <svg width="100%" height="100%" viewBox={`0 0 ${a.w} ${a.h}`} style={{overflow: 'visible'}}>
            <Person x={a.w / 2} y={a.h - 108 * s} s={s} shirt="#43A047" skin="#F1C27D" hair="#111" wave={wob(t, 8, 12)} />
            <g transform={`translate(${a.w / 2 + 70} ${a.h - 108 * s - 70}) scale(${pop(t, fps, 4)})`}>
              <ellipse rx={64} ry={52} fill="#fff" stroke="#111" strokeWidth={6} />
              <text y={22} textAnchor="middle" fontSize={72} fontWeight={900} fontFamily="Arial, sans-serif" fill="#111">?</text>
            </g>
          </svg>
        </Abs>
        <Stickman box={L.S10.char!} expr={k < 0.5 ? 'shock' : 'happy'} pose={blendPose(POSES.slump, POSES.stand, easeOutCubic(prog(t, 0, 14)))} f={t} fx={k < 0.5 ? ['bang'] : []} offsetY={-Math.sin(Math.min(1, t / 14) * Math.PI) * 40} />
      </Camera>
    </AbsoluteFill>
  );
}

// S11: close-up punchline, wajah penuh layar.
function S11() {
  const {t, fps} = useScene();
  const enter = pop(t, fps, 0, 8, 220);
  return (
    <AbsoluteFill style={{background: '#FFD36B'}}>
      <Burst box={FULL} f={t * 3} a="#FFE9A8" b="#FFB74D" n={24} speed={0.006} />
      <SpeedLines box={FULL} f={t} cx={540} cy={900} color="#fff" />
      <Stickman box={L.S11.char!} view="head" expr="joy" pose={POSES.stand} f={t} fx={['sparkle']} scale={0.7 + 0.3 * enter} shake={t < 12 ? 6 : 0} />
      <svg width={1080} height={1500} style={{position: 'absolute', left: 0, top: 0, overflow: 'visible'}}>
        <Star4 x={170 + wob(t, 18, 8)} y={520} r={34} />
        <Star4 x={930} y={660 + wob(t, 22, 8)} r={28} />
        <Star4 x={880} y={1180} r={22} />
      </svg>
    </AbsoluteFill>
  );
}

export const Beat3Antrean = ({beatFrom}: {beatFrom: number}) => (
  <>
    <SceneSeq id="S7" beatFrom={beatFrom}><S7 /></SceneSeq>
    <SceneSeq id="S8" beatFrom={beatFrom}><S8 /></SceneSeq>
    <SceneSeq id="S9" beatFrom={beatFrom}><S9 /></SceneSeq>
    <SceneSeq id="S10" beatFrom={beatFrom}><S10 /></SceneSeq>
    <SceneSeq id="S11" beatFrom={beatFrom}><S11 /></SceneSeq>
  </>
);
