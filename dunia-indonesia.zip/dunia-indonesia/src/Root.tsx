import {Composition} from 'remotion';
import {Main} from './Composition';
import {FPS, TOTAL_FRAMES} from './data/captions';
import {H, W} from './data/layout';

export const RemotionRoot = () => {
  return (
    <Composition
      id="DuniaJadiIndonesia"
      component={Main}
      durationInFrames={TOTAL_FRAMES}
      fps={FPS}
      width={W}
      height={H}
    />
  );
};
