import type {ReactNode} from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile} from 'remotion';
import {BEATS, SCENE_RANGE} from './data/captions';
import type {SceneId} from './data/captions';
import {leadOf} from './data/scenes';
import {ANIM_AREA, H, W} from './data/layout';
import {Subtitle} from './components/Subtitle';
import {Beat1Hook} from './scenes/Beat1Hook';
import {Beat2Populasi} from './scenes/Beat2Populasi';
import {Beat3Antrean} from './scenes/Beat3Antrean';
import {Beat4Kuliner} from './scenes/Beat4Kuliner';
import {Beat5WhatsApp} from './scenes/Beat5WhatsApp';
import {Beat6Ending} from './scenes/Beat6Ending';

const BEAT_COMPONENTS: Record<string, (p: {beatFrom: number}) => ReactNode> = {
  B1: Beat1Hook,
  B2: Beat2Populasi,
  B3: Beat3Antrean,
  B4: Beat4Kuliner,
  B5: Beat5WhatsApp,
  B6: Beat6Ending,
};

/** Panel bawah (di bawah area animasi) tempat subtitle berada. */
function BottomPanel() {
  const top = ANIM_AREA.y + ANIM_AREA.h;
  return (
    <div style={{position: 'absolute', left: 0, top, width: W, height: H - top, background: '#151515'}}>
      <svg width={W} height={H - top} style={{position: 'absolute', left: 0, top: 0}}>
        <defs>
          <pattern id="dots" width={28} height={28} patternUnits="userSpaceOnUse">
            <circle cx={14} cy={14} r={3} fill="#222" />
          </pattern>
        </defs>
        <rect x={0} y={0} width={W} height={H - top} fill="url(#dots)" />
        <rect x={0} y={0} width={W} height={10} fill="#FFD400" />
      </svg>
    </div>
  );
}

export const Main = () => {
  return (
    <AbsoluteFill style={{backgroundColor: '#151515'}}>
      <Audio src={staticFile('narasi.mp3')} />
      <BottomPanel />
      {BEATS.map((b) => {
        const first = b.scenes[0] as SceneId;
        const last = b.scenes[b.scenes.length - 1] as SceneId;
        const from = SCENE_RANGE[first].start - leadOf(first);
        const end = SCENE_RANGE[last].end;
        const Beat = BEAT_COMPONENTS[b.id];
        return (
          <Sequence key={b.id} from={from} durationInFrames={end - from} name={b.id}>
            <Beat beatFrom={from} />
          </Sequence>
        );
      })}
      <Subtitle />
    </AbsoluteFill>
  );
};
