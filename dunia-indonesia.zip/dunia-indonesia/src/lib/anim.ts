import {spring} from 'remotion';

export const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const prog = (f: number, start: number, dur: number) => clamp((f - start) / dur);

export const easeOutCubic = (t: number) => 1 - Math.pow(1 - clamp(t), 3);
export const easeInCubic = (t: number) => Math.pow(clamp(t), 3);
export const easeInOutCubic = (t: number) => {
  const x = clamp(t);
  return x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2;
};

/** Gelombang sinus deterministik (periode dalam frame). */
export const wob = (f: number, period: number, amp: number, phase = 0) =>
  Math.sin((f / period + phase) * Math.PI * 2) * amp;

/** Pseudo-random ber-seed (mulberry32). Selalu menghasilkan urutan sama untuk seed sama. */
export function rng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Spring "pop" dengan sedikit overshoot. */
export const pop = (t: number, fps: number, delay = 0, damping = 11, stiffness = 150) =>
  spring({frame: t - delay, fps, config: {damping, mass: 0.6, stiffness}});

export const fmtDots = (n: number) => String(Math.floor(n)).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
