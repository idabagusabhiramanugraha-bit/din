import {createContext, useContext} from 'react';
import type {ReactNode} from 'react';
import {Sequence, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneId} from '../data/captions';
import {SCENE_RANGE} from '../data/captions';
import {LEAD_FRAMES, SCENE_ENTER, leadOf} from '../data/scenes';
import type {Enter} from '../data/scenes';
import {ANIM_AREA} from '../data/layout';
import {easeInOutCubic, easeOutCubic, prog} from './anim';

const SceneCtx = createContext({lead: 0});

/** Waktu lokal scene: t = frame sejak scene dimulai (setelah lead), dur = durasi scene. */
export function useScene() {
  const f = useCurrentFrame();
  const {durationInFrames, fps} = useVideoConfig();
  const {lead} = useContext(SceneCtx);
  const t = Math.max(0, f - lead);
  const dur = durationInFrames - lead;
  return {f, t, dur, fps, p: dur > 0 ? Math.min(1, t / dur) : 0};
}

function Shell({enter, lead, children}: {enter: Enter; lead: number; children: ReactNode}) {
  const f = useCurrentFrame();
  const p = lead > 0 ? easeInOutCubic(prog(f, 0, LEAD_FRAMES)) : 1;
  let clipPath: string | undefined;
  let transform: string | undefined;
  let filter: string | undefined;
  if (enter === 'wipe') {
    const x = p * 130;
    clipPath = `polygon(0% 0%, ${x}% 0%, ${x - 30}% 100%, 0% 100%)`;
  } else if (enter === 'iris') {
    clipPath = `circle(${p * 110}% at 50% 50%)`;
  } else if (enter === 'swipeUp') {
    transform = `translateY(${(1 - p) * ANIM_AREA.h}px)`;
  } else if (enter === 'whip') {
    transform = `translateX(${(1 - p) * ANIM_AREA.w}px)`;
    filter = `blur(${(1 - p) * 10}px)`;
  } else if (enter === 'stamp') {
    const s = 1 + 0.18 * (1 - easeOutCubic(prog(f, 0, 6)));
    transform = `scale(${s})`;
  }
  const flash = enter === 'stamp' ? Math.max(0, 1 - f / 4) : 0;
  return (
    <div
      style={{
        position: 'absolute',
        left: ANIM_AREA.x,
        top: ANIM_AREA.y,
        width: ANIM_AREA.w,
        height: ANIM_AREA.h,
        overflow: 'hidden',
        clipPath,
        transform,
        filter,
        transformOrigin: '50% 50%',
      }}
    >
      {children}
      {flash > 0 ? (
        <div style={{position: 'absolute', inset: 0, background: '#fff', opacity: flash * 0.85}} />
      ) : null}
    </div>
  );
}

export function SceneSeq({id, beatFrom, children}: {id: SceneId; beatFrom: number; children: ReactNode}) {
  const r = SCENE_RANGE[id];
  const lead = leadOf(id);
  return (
    <Sequence from={r.start - lead - beatFrom} durationInFrames={r.end - r.start + lead} name={id}>
      <SceneCtx.Provider value={{lead}}>
        <Shell enter={SCENE_ENTER[id]} lead={lead}>
          {children}
        </Shell>
      </SceneCtx.Provider>
    </Sequence>
  );
}
