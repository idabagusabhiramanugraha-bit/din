import type {ReactNode} from 'react';
import {easeInOutCubic} from './anim';
import {ANIM_AREA} from '../data/layout';

type Pair = [number, number];

/**
 * Kamera deterministik: [dari, ke] untuk skala, geser x/y (px), rotasi (derajat).
 * origin = titik fokus (px, koordinat kanvas).
 */
export function Camera({
  t, dur, s = [1, 1], x = [0, 0], y = [0, 0], r = [0, 0], origin = [540, 750], ease = easeInOutCubic, children,
}: {
  t: number; dur: number; s?: Pair; x?: Pair; y?: Pair; r?: Pair; origin?: Pair;
  ease?: (v: number) => number; children: ReactNode;
}) {
  const p = ease(dur > 0 ? t / dur : 0);
  const v = (a: Pair) => a[0] + (a[1] - a[0]) * p;
  return (
    <div
      style={{
        position: 'absolute',
        left: 0,
        top: 0,
        width: ANIM_AREA.w,
        height: ANIM_AREA.h,
        transformOrigin: `${origin[0]}px ${origin[1]}px`,
        transform: `translate(${v(x)}px, ${v(y)}px) scale(${v(s)}) rotate(${v(r)}deg)`,
      }}
    >
      {children}
    </div>
  );
}
