// Validator Tahap 3. Jalankan: npm run validate
// Membaca src/data/captions.ts dan src/data/layout.ts (tanpa import) lewat transpile TypeScript.
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {fileURLToPath, pathToFileURL} from 'node:url';

const require = createRequire(import.meta.url);
const ts = require('typescript');
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const tmp = fs.mkdtempSync(path.join(root, '.val-'));

async function load(rel) {
  const src = fs.readFileSync(path.join(root, rel), 'utf8');
  const out = ts.transpileModule(src, {compilerOptions: {module: ts.ModuleKind.ESNext, target: ts.ScriptTarget.ES2022}}).outputText;
  const f = path.join(tmp, path.basename(rel).replace('.ts', '.mjs'));
  fs.writeFileSync(f, out);
  return import(pathToFileURL(f).href);
}

const errors = [];
const warns = [];
const ok = (m) => console.log('  OK   ' + m);
const bad = (m) => { errors.push(m); console.log('  GAGAL ' + m); };
const warn = (m) => { warns.push(m); console.log('  CATATAN ' + m); };

try {
  const C = await load('src/data/captions.ts');
  const Ly = await load('src/data/layout.ts');
  const {FPS, TOTAL_FRAMES, WORDS, PAGES, SCENE_ORDER, SCENE_RANGE, LAST_WORD_END, CUES} = C;

  console.log('\n[1] Durasi dan sinkronisasi');
  const expected = Math.round((LAST_WORD_END + 1 + C.AUDIO_OFFSET) * FPS);
  TOTAL_FRAMES === expected ? ok(`TOTAL_FRAMES=${TOTAL_FRAMES} (${(TOTAL_FRAMES / FPS).toFixed(2)} dtk) = kata terakhir ${LAST_WORD_END.toFixed(2)} dtk + 1 dtk`) : bad('durasi total salah');
  CUES.every((c, i) => i === 0 || Math.abs(c.start - CUES[i - 1].end) < 1e-9) ? ok('cue SRT berurutan tanpa celah') : bad('ada celah/tumpang tindih antar cue SRT');
  WORDS.every((w, i) => w.end > w.start && (i === 0 || w.start >= WORDS[i - 1].start - 1e-9)) ? ok(`${WORDS.length} kata punya timing monoton`) : bad('timing kata tidak monoton');

  console.log('\n[2] Subtitle');
  let maxLine = 0;
  let pagesOk = true;
  PAGES.forEach((p, i) => {
    if (p.lines.length > 2) { pagesOk = false; bad(`halaman ${i} lebih dari 2 baris`); }
    p.lines.forEach((l) => { maxLine = Math.max(maxLine, l.map((w) => w.text).join(' ').length); });
    if (p.endFrame <= p.startFrame) { pagesOk = false; bad(`halaman ${i} durasi <= 0`); }
    if (i > 0 && p.startFrame !== PAGES[i - 1].endFrame) { pagesOk = false; bad(`celah subtitle di halaman ${i}`); }
  });
  if (pagesOk) ok(`${PAGES.length} halaman, maks 2 baris, tanpa celah kosong`);
  // perkiraan lebar: font 60px Arial Black ~ 0.62em per huruf + padding sorotan
  const estW = (txt) => txt.length * 56 * 0.62;
  const worstW = Math.max(...PAGES.flatMap((p) => p.lines.map((l) => estW(l.map((w) => w.text).join(' ')) + l.length * 16 + l.filter((w) => w.highlight).length * 24)));
  worstW <= Ly.SUBTITLE_BOX.w ? ok(`baris terpanjang ${maxLine} huruf, perkiraan lebar ${Math.round(worstW)}px <= ${Ly.SUBTITLE_BOX.w}px`) : warn(`baris terpanjang perkiraan ${Math.round(worstW)}px > ${Ly.SUBTITLE_BOX.w}px; kecilkan FONT_SIZE di Subtitle.tsx`);
  const shortest = Math.min(...PAGES.map((p) => p.endFrame - p.startFrame));
  shortest >= 12 ? ok(`halaman subtitle tersingkat ${shortest} frame (${(shortest / FPS).toFixed(2)} dtk)`) : warn(`halaman subtitle tersingkat hanya ${shortest} frame`);

  console.log('\n[3] Scene dan beat');
  let prev = 0;
  let sceneOk = true;
  const durs = [];
  for (const id of SCENE_ORDER) {
    const r = SCENE_RANGE[id];
    if (r.start !== prev) { sceneOk = false; bad(`${id} mulai ${r.start}, seharusnya ${prev} (celah/tumpang tindih)`); }
    if (r.end <= r.start) { sceneOk = false; bad(`${id} durasi <= 0`); }
    durs.push([id, r.end - r.start]);
    prev = r.end;
  }
  if (prev !== TOTAL_FRAMES) { sceneOk = false; bad('scene terakhir tidak berakhir di TOTAL_FRAMES'); }
  if (sceneOk) ok(`21 scene menutup 0..${TOTAL_FRAMES} tanpa jeda kosong`);
  durs.forEach(([id, d]) => {
    if (d < 45) warn(`${id} hanya ${d} frame (${(d / FPS).toFixed(2)} dtk): cukup cepat`);
    if (d > 190) warn(`${id} ${d} frame (${(d / FPS).toFixed(2)} dtk): cukup lama, pastikan ada gerak berlanjut`);
  });
  const mins = Math.min(...durs.map((x) => x[1]));
  const maxs = Math.max(...durs.map((x) => x[1]));
  ok(`durasi scene ${mins}..${maxs} frame (${(mins / FPS).toFixed(1)}..${(maxs / FPS).toFixed(1)} dtk)`);

  console.log('\n[4] Koordinat dan tumpang tindih');
  const inside = (b, a) => b.x >= a.x && b.y >= a.y && b.x + b.w <= a.x + a.w && b.y + b.h <= a.y + a.h;
  const inter = (a, b) => Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x) > 1 && Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y) > 1;
  const full = {x: 0, y: 0, w: Ly.W, h: Ly.H};
  let n = 0;
  if (!inside(Ly.ANIM_AREA, full)) bad('ANIM_AREA keluar kanvas');
  if (inter(Ly.ANIM_AREA, Ly.SUBTITLE_BOX)) bad('area animasi menimpa subtitle'); else ok('subtitle berada di bawah area animasi');
  if (!inside(Ly.SUBTITLE_BOX, full) || Ly.SUBTITLE_BOX.x < 60 || Ly.SUBTITLE_BOX.x + Ly.SUBTITLE_BOX.w > Ly.W - 60 || Ly.SUBTITLE_BOX.y + Ly.SUBTITLE_BOX.h > Ly.H - 100) bad('subtitle terlalu dekat tepi layar'); else ok('subtitle punya margin aman dari tepi (>=60px kiri/kanan, >=100px bawah)');
  for (const [id, s] of Object.entries(Ly.SCENE_LAYOUT)) {
    if (s.char) {
      if (!inside(s.char, Ly.ANIM_AREA)) bad(`${id}: karakter keluar area animasi`);
      if (s.char.x < Ly.SAFE_MARGIN || s.char.x + s.char.w > Ly.W - Ly.SAFE_MARGIN) bad(`${id}: karakter melewati margin aman horizontal`);
      if (s.char.y + s.char.h > Ly.ANIM_AREA.h - 20) bad(`${id}: karakter menyentuh batas bawah area`);
      if (s.label !== false && inter(s.char, Ly.LABEL_BOX) && s.label) bad(`${id}: karakter menimpa label`);
    }
    if (s.label) {
      for (const [k, o] of Object.entries(s.objs)) if (!o.bg && inter(o, Ly.LABEL_BOX)) bad(`${id}: objek ${k} menimpa label`);
    }
    const objs = Object.entries(s.objs).filter(([, o]) => !o.bg);
    for (const [k, o] of objs) {
      if (!inside(o, Ly.ANIM_AREA)) bad(`${id}: objek ${k} keluar area animasi`);
      if (s.char && !o.ok && inter(o, s.char)) bad(`${id}: objek ${k} bertabrakan dengan karakter (tidak ditandai disengaja)`);
      n++;
    }
    for (let i = 0; i < objs.length; i++) for (let j = i + 1; j < objs.length; j++) {
      if (!objs[i][1].ok && !objs[j][1].ok && inter(objs[i][1], objs[j][1])) bad(`${id}: ${objs[i][0]} bertabrakan dengan ${objs[j][0]}`);
    }
  }
  ok(`${Object.keys(Ly.SCENE_LAYOUT).length} scene diperiksa, ${n} objek non-latar; tumpang tindih disengaja ditandai ok:true`);

  console.log('\n[5] Determinisme kode sumber');
  const forbidden = [
    [/\bMath\.random\b/, 'Math.random'], [/\bsetTimeout\b|\bsetInterval\b/, 'setTimeout/setInterval'],
    [/\bDate\.now\b|\bnew Date\b|performance\.now/, 'waktu browser'], [/@keyframes|\banimation\s*:|\btransition\s*:/, 'CSS animation/transition'],
    [/requestAnimationFrame/, 'requestAnimationFrame'],
  ];
  const walk = (d) => fs.readdirSync(d, {withFileTypes: true}).flatMap((e) => (e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]));
  let det = true;
  for (const f of walk(path.join(root, 'src')).filter((p) => /\.(ts|tsx)$/.test(p))) {
    const code = fs.readFileSync(f, 'utf8').replace(/\/\/.*$/gm, '').replace(/\/\*[\s\S]*?\*\//g, '');
    for (const [re, name] of forbidden) if (re.test(code)) { det = false; bad(`${path.relative(root, f)} memakai ${name}`); }
  }
  if (det) ok('tidak ada Math.random, timer, waktu browser, atau CSS animation');

  console.log('\n[6] Berkas pendukung');
  fs.existsSync(path.join(root, 'public/narasi.mp3')) ? ok('public/narasi.mp3 ada') : warn('public/narasi.mp3 BELUM ADA: taruh file audio narasi di public/narasi.mp3 sebelum npm run dev/render');
} finally {
  fs.rmSync(tmp, {recursive: true, force: true});
}

console.log(`\nHasil: ${errors.length} gagal, ${warns.length} catatan.`);
process.exit(errors.length ? 1 : 0);
