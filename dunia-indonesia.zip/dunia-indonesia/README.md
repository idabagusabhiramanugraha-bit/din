# Bagaimana Jika Seluruh Manusia di Dunia Menjadi Orang Indonesia?

Video animasi edukasi-komedi Remotion, 1080x1920 (9:16), 30 fps, 2119 frame (70,6 detik).
Semua paket Remotion dikunci di versi **4.0.321** (tanpa tanda ^).

## Yang harus Anda siapkan dulu
Taruh file audio narasi Anda di **`public/narasi.mp3`**. File ini tidak ikut di ZIP karena tidak saya terima.
Durasi audio harus sekitar 69,6 detik, sesuai SRT. Jika suara terasa lebih cepat/lambat dari subtitle, ubah `AUDIO_OFFSET` (detik) di `src/data/captions.ts`.

## Tutorial Windows untuk pemula
1. **Pasang Node.js.** Buka https://nodejs.org, unduh versi **LTS** (22 atau 20), jalankan installer, klik Next sampai selesai. Cek: buka Command Prompt, ketik `node -v` lalu Enter; harus muncul nomor versi.
2. **Ekstrak ZIP.** Klik kanan `dunia-indonesia.zip` > Extract All, simpan di mis. `C:\video\dunia-indonesia`.
3. **Buka terminal di folder proyek.** Buka folder hasil ekstrak di File Explorer, klik kolom alamat di atas, ketik `cmd`, tekan Enter.
4. **Pasang paket:** `npm install` (butuh internet, beberapa menit, jangan ditutup).
5. **Pratinjau:** `npm run dev`. Browser terbuka di Remotion Studio (http://localhost:3000). Pilih komposisi `DuniaJadiIndonesia`, tekan Spasi untuk memutar.
6. **Render MP4:** `npm run render`. Hasil ada di `out/video.mp4`. Pada render pertama Remotion mengunduh Chrome Headless sendiri; tunggu saja.

Perintah tambahan: `npm run validate` memeriksa timing, tata letak, dan determinisme (tidak butuh `npm install`; butuh paket `typescript`, otomatis ada setelah install).

## Alternatif jika hanya punya HP Android (tanpa Node.js)
Remotion tidak berjalan native di Android. Pilihan:
- **Termux** (dari F-Droid, bukan Play Store): `pkg install nodejs`, lalu langkah 4-6 di atas. Keterbatasan: render Chrome Headless sering gagal/sangat lambat di ARM Android, RAM 4 GB+ disarankan, tidak ada Studio yang nyaman.
- **Codespaces/Gitpod (cloud, lewat browser HP)**: unggah proyek ke GitHub, buka di Codespaces, jalankan `npm install` dan `npm run render`, unduh `out/video.mp4`. Keterbatasan: perlu akun GitHub, ada kuota jam gratis.
- **Pinjam komputer** hanya untuk render, lalu kirim MP4 ke HP: paling andal.

## Diagnosis error umum
- `'node' is not recognized`: Node.js belum terpasang atau terminal belum dibuka ulang setelah instal.
- `ENOENT ... narasi.mp3` / audio tidak terdengar: file belum ada di `public/narasi.mp3` (nama harus persis).
- `npm ERR! code ETARGET / ERESOLVE`: pastikan memakai `package.json` bawaan, jangan jalankan `npm update`.
- Render berhenti di "Downloading Chrome": koneksi terputus; jalankan ulang `npm run render`.
- Error memori saat render: tutup aplikasi lain, atau render dengan `npx remotion render src/index.ts DuniaJadiIndonesia out/video.mp4 --concurrency=2`.
Jika ada pesan error lain, salin teksnya persis dan kirim ke saya.

## Struktur
- `src/data/captions.ts` : timestamp SRT, `AUDIO_OFFSET`, timing kata, batas scene, halaman subtitle
- `src/data/layout.ts` : semua koordinat eksplisit (tanpa header; label di y=150, subtitle di y=1520)
- `src/data/scenes.ts` : jenis transisi per scene
- `src/scenes/Beat1..6*.tsx` : 6 beat, 21 scene, masing-masing dibungkus `Sequence`
- `src/components/` : karakter (`Stickman.tsx`), objek ilustrasi, label, subtitle
